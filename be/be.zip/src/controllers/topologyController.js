import TopologyNode from '../models/TopologyNode.js';
import TopologyEdge from '../models/TopologyEdge.js';

export const getTopology = async (req, res) => {
    try {
        const nodesData = await TopologyNode.findAll();
        const edgesData = await TopologyEdge.findAll();

        const formattedNodes = nodesData.map(node => ({
            id: node.id,
            type: node.type,
            data: {
                label: node.label,
                layer: node.layer,
                ip: node.ip,
                category: node.category,
                subType: node.subType,
                vlan: node.vlan,
                location: node.location,
                floor: node.floor,
                status: 'down', // Default status, will be updated by frontend socket/API logic
                cpu: '0%'
            },
            position: {
                x: node.x_pos,
                y: node.y_pos
            }
        }));

        const formattedEdges = edgesData.map(edge => ({
            id: edge.id,
            source: edge.source,
            target: edge.target,
            animated: edge.animated,
            style: {
                stroke: edge.stroke_color,
                strokeWidth: edge.stroke_width,
                strokeDasharray: edge.stroke_dasharray
            }
        }));

        res.status(200).json({ success: true, nodes: formattedNodes, edges: formattedEdges });
    } catch (error) {
        console.error('❌ [Get Topology Error]:', error);
        res.status(500).json({ success: false, error: 'Gagal mengambil data topologi.' });
    }
};
