import Floorplan from '../models/Floorplan.js';
import Network from '../models/Network.js';
import Asset from '../models/Asset.js';
import { Op } from 'sequelize';

// Ambil daftar ringkas seluruh denah
export const getAllFloorplans = async (req, res) => {
    try {
        // ⚠️ JANGAN PANGGIL Floorplan.sync() DI SINI
        let floorplans = await Floorplan.findAll({
            attributes: ['id', 'name', 'type', 'description', 'updatedAt'],
            order: [['type', 'ASC'], ['id', 'ASC']]
        });

        // Buat 1 Master Plan default jika database masih kosong
        if (floorplans.length === 0) {
            const defaultMaster = await Floorplan.create({
                name: 'Master Facility Blueprint',
                type: 'MASTER',
                description: 'Denah Utama Seluruh Area Site Facility',
                lines: [],
                rooms: [],
                devices: []
            });
            floorplans = [defaultMaster];
        }

        return res.status(200).json({
            success: true,
            data: floorplans
        });
    } catch (error) {
        console.error('❌ Error getAllFloorplans:', error);
        return res.status(500).json({ success: false, message: error.message });
    }
};

// Ambil 1 denah lengkap berdasarkan ID
export const getFloorplanById = async (req, res) => {
    try {
        const { id } = req.params;
        const floorplan = await Floorplan.findByPk(id);

        if (!floorplan) {
            return res.status(404).json({ success: false, message: 'Denah tidak ditemukan' });
        }

        return res.status(200).json({ success: true, data: floorplan });
    } catch (error) {
        console.error('❌ Error getFloorplanById:', error);
        return res.status(500).json({ success: false, message: error.message });
    }
};

// Simpan atau Perbarui Denah (Create / Update)
export const saveFloorplan = async (req, res) => {
    try {
        const { id, name, type = 'DETAIL', description, lines, rooms, devices } = req.body;

        let floorplan;

        if (id) {
            floorplan = await Floorplan.findByPk(id);
            if (floorplan) {
                if (name) floorplan.name = name;
                if (type) floorplan.type = type;
                if (description !== undefined) floorplan.description = description;
                floorplan.lines = lines;
                floorplan.rooms = rooms;
                floorplan.devices = devices;
                await floorplan.save();
            }
        }

        if (!floorplan) {
            floorplan = await Floorplan.create({
                name: name || 'Denah Baru',
                type,
                description,
                lines: lines || [],
                rooms: rooms || [],
                devices: devices || []
            });
        }

        // Auto-sync devices placed on floorplan to Network & Asset DB
        if (devices && Array.isArray(devices) && devices.length > 0) {
            for (const dev of devices) {
                const hostname = dev.label || dev.name;
                if (!hostname) continue;

                try {
                    let existingNet = await Network.findOne({ where: { HOSTNAME: hostname } });
                    let netPid;

                    if (!existingNet) {
                        const candidate = `P-${String(dev.id || hostname).replace(/[^a-zA-Z0-9]/g, '')}`.substring(0, 12);
                        netPid = `${candidate}-${Date.now().toString().slice(-4)}${Math.floor(Math.random() * 90 + 10)}`.substring(0, 20);

                        let count = 0;
                        while (await Network.findByPk(netPid) && count < 5) {
                            netPid = `P-${Date.now().toString().slice(-10)}${Math.floor(Math.random() * 900 + 100)}`.substring(0, 20);
                            count++;
                        }

                        existingNet = await Network.create({
                            PID: netPid,
                            HOSTNAME: hostname,
                            IP: dev.ip || '192.168.1.100',
                            MAC: '-',
                            SWITCH: '-',
                            PORT: '-',
                            SEGMENT: name || 'DEFAULT',
                        });
                    } else {
                        netPid = existingNet.PID;
                        if (name && existingNet.SEGMENT !== name) {
                            existingNet.SEGMENT = name;
                            await existingNet.save();
                        }
                    }

                    let existingAsset = await Asset.findOne({
                        where: {
                            [Op.or]: [{ HOSTNAME: hostname }, { PID: netPid }]
                        }
                    });

                    if (!existingAsset) {
                        let assetPid = netPid;
                        let count = 0;
                        while (await Asset.findByPk(assetPid) && count < 5) {
                            assetPid = `A-${Date.now().toString().slice(-10)}${Math.floor(Math.random() * 900 + 100)}`.substring(0, 20);
                            count++;
                        }

                        await Asset.create({
                            PID: assetPid,
                            ASSET: dev.vendor || 'Generic',
                            STATUS: 'UP',
                            HOSTNAME: hostname,
                        });
                    }
                } catch (dbErr) {
                    const detailMsg = dbErr.errors ? dbErr.errors.map(e => e.message).join(', ') : dbErr.message;
                    console.error(`⚠️ Sync device ${hostname} skipped:`, detailMsg);
                }
            }
        }

        return res.status(200).json({
            success: true,
            message: 'Denah & Perangkat berhasil disimpan dan disinkronisasi!',
            data: floorplan
        });
    } catch (error) {
        console.error('❌ Error saveFloorplan:', error);
        return res.status(500).json({ success: false, message: error.message });
    }
};

// Hapus Denah Detail
export const deleteFloorplan = async (req, res) => {
    try {
        const { id } = req.params;
        const floorplan = await Floorplan.findByPk(id);

        if (!floorplan) {
            return res.status(404).json({ success: false, message: 'Denah tidak ditemukan' });
        }

        // Validasi MASTER dihapus sesuai permintaan

        await floorplan.destroy();

        return res.status(200).json({
            success: true,
            message: 'Denah berhasil dihapus'
        });
    } catch (error) {
        console.error('❌ Error deleteFloorplan:', error);
        return res.status(500).json({ success: false, message: error.message });
    }
};