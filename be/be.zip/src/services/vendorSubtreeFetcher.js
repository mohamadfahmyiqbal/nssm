import snmp from 'net-snmp';

/**
 * Walk Subtree helper
 */
export const walkSubtreeList = (session, rootOid, maxRepetitions = 20, mapFn) => {
    return new Promise((resolve) => {
        const list = [];
        session.subtree(rootOid, maxRepetitions, (row) => {
            row.forEach(vb => {
                if (!snmp.isVarbindError(vb)) {
                    if (mapFn) {
                        const item = mapFn(vb);
                        if (item) list.push(item);
                    } else {
                        list.push({ status: vb.value.toString() });
                    }
                }
            });
        }, () => resolve(list));
    });
};

/**
 * Tarik Port Switch (Physical Interfaces)
 */
export const fetchSwitchPorts = async (session) => {
    let ifDescrs = {};
    let portList = [];

    await new Promise((res) => {
        session.subtree('1.3.6.1.2.1.2.2.1.2', 48, (row) => {
            row.forEach(vb => {
                if (!snmp.isVarbindError(vb)) {
                    const idx = vb.oid.toString().split('.').pop();
                    ifDescrs[idx] = vb.value.toString();
                }
            });
        }, res);
    });

    return new Promise((res) => {
        session.subtree('1.3.6.1.2.1.2.2.1.8', 48, (row) => {
            row.forEach(vb => {
                if (!snmp.isVarbindError(vb)) {
                    const idx = vb.oid.toString().split('.').pop();
                    const descr = ifDescrs[idx] || '';
                    const descrLower = descr.toLowerCase();
                    const isPhysical = descrLower.includes('ethernet') || (descrLower.includes('port') && !descrLower.includes('stack'));
                    const isLogical = descrLower.includes('vlan') || descrLower.includes('null') || descrLower.includes('loopback');
                    if (isPhysical && !isLogical) {
                        portList.push({
                            index: idx,
                            name: descr,
                            shortName: idx,
                            status: vb.value === 1 ? 'up' : 'down'
                        });
                    }
                }
            });
        }, () => res(portList));
    });
};
