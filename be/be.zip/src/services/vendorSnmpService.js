import snmp from 'net-snmp';
import { createSnmpSession } from './snmpV3Service.js';
import { DEFAULT_VENDOR_PROFILES, resolveVendorProfile } from './vendorRegistry.js';
import { fetchStandardMetrics, formatHardwareStatus } from './vendorSnmpHelpers.js';
import { walkSubtreeList, fetchSwitchPorts } from './vendorSubtreeFetcher.js';

export { DEFAULT_VENDOR_PROFILES, resolveVendorProfile };

/**
 * Menarik metrik vendor spesifik secara terisolasi per OID
 */
const fetchSpecificOids = async (session, profile) => {
    const specificOids = [];
    const specificKeys = [];

    if (profile.cpuOid) { specificOids.push(profile.cpuOid); specificKeys.push('cpu'); }
    if (profile.temperatureOid) { specificOids.push(profile.temperatureOid); specificKeys.push('temperature'); }
    if (profile.voltageOid) { specificOids.push(profile.voltageOid); specificKeys.push('voltage'); }
    if (profile.memoryUsedOid) { specificOids.push(profile.memoryUsedOid); specificKeys.push('memUsed'); }
    if (profile.memoryFreeOid) { specificOids.push(profile.memoryFreeOid); specificKeys.push('memFree'); }

    if (profile.sysInfoOids && Array.isArray(profile.sysInfoOids)) {
        profile.sysInfoOids.forEach(item => {
            specificOids.push(item.oid);
            specificKeys.push(item.key);
        });
    }

    if (specificOids.length === 0) return { info: {}, resources: {} };

    const specVarbinds = await Promise.all(
        specificOids.map(oid => new Promise(res => {
            session.get([oid], (err, vbs) => {
                if (err || !vbs || vbs.length === 0 || snmp.isVarbindError(vbs[0])) {
                    res(null);
                } else {
                    res(vbs[0]);
                }
            });
        }))
    );

    const info = {};
    const resources = {};

    specVarbinds.forEach((vb, idx) => {
        if (vb && !snmp.isVarbindError(vb)) {
            const key = specificKeys[idx];
            const val = vb.value ? vb.value.toString() : 'N/A';
            if (['cpu', 'temperature', 'voltage', 'memUsed', 'memFree'].includes(key)) {
                resources[key] = val;
            } else {
                info[key] = formatHardwareStatus(key, val);
            }
        }
    });

    if (resources.memUsed && resources.memFree) {
        const u = parseFloat(resources.memUsed);
        const f = parseFloat(resources.memFree);
        if (!isNaN(u) && !isNaN(f) && (u + f) > 0) {
            resources.memory = `${Math.round((u / (u + f)) * 100)}%`;
        }
    }

    return { info, resources };
};

/**
 * Controller utama penarikan metrik perangkat
 */
export const fetchVendorMetrics = async (ip, credential, profile) => {
    return new Promise(async (resolve) => {
        const session = createSnmpSession(ip, credential, { retries: 2, timeout: 5000 });
        let isClosed = false;
        const originalClose = session.close.bind(session);
        session.close = () => {
            if (!isClosed) {
                isClosed = true;
                try { originalClose(); } catch (e) {}
            }
        };

        session.on('error', () => {
            session.close();
            resolve(null);
        });

        const result = {
            vendor: profile.name,
            vendorId: profile.id,
            category: profile.category,
            info: {},
            resources: {},
            hdd: [],
            cameras: [],
            ports: []
        };

        try {
            // 1. MIB-2 Standar
            const stdData = await fetchStandardMetrics(session);
            result.info = { ...result.info, ...(stdData.info || {}) };
            result.resources = { ...result.resources, ...(stdData.resources || {}) };

            // 2. Metrik Vendor Spesifik (CPU / RAM / Suhu / Hardware status)
            const specData = await fetchSpecificOids(session, profile);
            result.info = { ...result.info, ...(specData.info || {}) };
            result.resources = { ...result.resources, ...(specData.resources || {}) };

            // 3. Fallback Firmware Panasonic jika di sysDescr
            if (profile.id === 'panasonic' && (!result.info.firmware || result.info.firmware === 'N/A') && result.info.sysDescr) {
                const match = result.info.sysDescr.match(/SWVer([\d\.]+)/i) || result.info.sysDescr.match(/Ver\.?\s*([\d\.]+)/i);
                if (match) result.info.firmware = match[1];
            }

            // 4. Subtree HDD
            if (profile.hddSubtree) {
                result.hdd = await walkSubtreeList(session, profile.hddSubtree, 10);
            }

            // 5. Subtree Kamera (Channels & Camera IPs)
            if (profile.cameraSubtree) {
                const cameraMap = {};
                await new Promise((res) => {
                    session.subtree(profile.cameraSubtree, 300, (camVarbinds) => {
                        camVarbinds.forEach(vb => {
                            if (!snmp.isVarbindError(vb)) {
                                const oidStr = vb.oid.toString();
                                const valStr = vb.value ? vb.value.toString() : '';
                                const parts = oidStr.split('.');
                                const camIdx = parts[parts.length - 2] || parts[parts.length - 1];

                                if (!cameraMap[camIdx]) cameraMap[camIdx] = { channel: camIdx, status: 'Disconnected', ip: '' };

                                if (valStr === '1') {
                                    cameraMap[camIdx].status = 'Connected';
                                } else if (valStr === '0' || valStr === '2') {
                                    cameraMap[camIdx].status = 'Disconnected';
                                } else if (valStr.includes('.')) {
                                    cameraMap[camIdx].ip = valStr;
                                }
                            }
                        });
                    }, () => {
                        result.cameras = Object.values(cameraMap);
                        res();
                    });
                });
            }

            // 6. Interfaces / Ports (Switch)
            if (profile.isSwitch) {
                result.ports = await fetchSwitchPorts(session);
            }

            session.close();
            resolve(result);
        } catch (err) {
            session.close();
            resolve(result);
        }
    });
};
