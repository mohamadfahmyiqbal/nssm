export const DEFAULT_VENDOR_PROFILES = {
    cisco: {
        id: 'cisco',
        name: 'Cisco Systems',
        category: 'switch',
        defaultMethod: 'snmp',
        aliases: ['cisco', 'catalyst', 'nexus'],
        cpuOid: '1.3.6.1.4.1.9.9.109.1.1.1.1.5.1', // 5-minute CPU
        memoryUsedOid: '1.3.6.1.4.1.9.9.48.1.1.1.5.1',
        memoryFreeOid: '1.3.6.1.4.1.9.9.48.1.1.1.6.1',
        isSwitch: true
    },
    ruijie: {
        id: 'ruijie',
        name: 'Ruijie Networks / Reyee',
        category: 'switch',
        defaultMethod: 'snmp',
        aliases: ['ruijie', 'reyee'],
        cpuOid: '1.3.6.1.4.1.4881.1.1.10.2.36.1.1.1.0',
        memoryUsedOid: '1.3.6.1.4.1.4881.1.1.10.2.35.1.1.1.2.0',
        memoryFreeOid: '1.3.6.1.4.1.4881.1.1.10.2.35.1.1.1.3.0',
        isSwitch: true
    },
    mikrotik: {
        id: 'mikrotik',
        name: 'MikroTik RouterOS',
        category: 'router',
        defaultMethod: 'snmp',
        aliases: ['mikrotik', 'routerboard'],
        cpuOid: '1.3.6.1.4.1.14988.1.1.1.2.1.1.0',
        temperatureOid: '1.3.6.1.4.1.14988.1.1.3.10.0',
        voltageOid: '1.3.6.1.4.1.14988.1.1.3.8.0',
        isSwitch: true
    },
    hpe: {
        id: 'hpe',
        name: 'HPE / Aruba',
        category: 'switch',
        defaultMethod: 'snmp',
        aliases: ['hpe', 'aruba', 'procurve', 'hp'],
        cpuOid: '1.3.6.1.4.1.11.2.14.11.5.1.9.6.1.0',
        isSwitch: true
    },
    ipro: {
        id: 'ipro',
        name: 'i-PRO',
        category: 'nvr',
        defaultMethod: 'snmp',
        aliases: ['ipro', 'i-pro', 'nx510', 'nx-510', 'nx410', 'nx-410'],
        sysInfoOids: [
            { key: 'manufacturer', oid: '1.3.6.1.4.1.57501.1.1.0' },
            { key: 'model', oid: '1.3.6.1.4.1.57501.1.2.0' },
            { key: 'serialNumber', oid: '1.3.6.1.4.1.57501.1.3.0' },
            { key: 'firmware', oid: '1.3.6.1.4.1.57501.1.4.0' },
            { key: 'userAccessCount', oid: '1.3.6.1.4.1.57501.200.1.2.1.0' },
            { key: 'alarmSummary', oid: '1.3.6.1.4.1.57501.200.1.2.2.0' },
            { key: 'temperature', oid: '1.3.6.1.4.1.57501.200.1.16.2.1.0' },
            { key: 'fanStatus', oid: '1.3.6.1.4.1.57501.200.1.16.1.1.0' },
            { key: 'psuStatus', oid: '1.3.6.1.4.1.57501.200.1.16.3.1.0' },
            { key: 'raidStatus', oid: '1.3.6.1.4.1.57501.200.1.13.2.1.0' },
            { key: 'recordingState', oid: '1.3.6.1.4.1.57501.200.1.14.1.0' },
        ],
        hddSubtree: '1.3.6.1.4.1.57501.200.1.13.1',
        cameraSubtree: '1.3.6.1.4.1.57501.200.1.15',
        isNvr: true
    },
    panasonic: {
        id: 'panasonic',
        name: 'Panasonic',
        category: 'nvr',
        defaultMethod: 'snmp',
        aliases: ['panasonic', 'wv-', 'wj-', 'wj-nx', 'nx400', 'nx-400', 'nx300', 'nx-300'],
        sysInfoOids: [
            { key: 'manufacturer', oid: '1.3.6.1.4.1.258.1.2.1.1.0' },
            { key: 'model', oid: '1.3.6.1.4.1.258.1.2.1.2.0' },
            { key: 'serialNumber', oid: '1.3.6.1.4.1.258.1.2.1.13.0' },
            { key: 'userAccessCount', oid: '1.3.6.1.4.1.258.5100.1.1.0' },
            { key: 'alarmSummary', oid: '1.3.6.1.4.1.258.5100.1.2.0' },
            { key: 'temperature', oid: '1.3.6.1.4.1.258.5100.200.1.16.2.1.0' },
            { key: 'fanStatus', oid: '1.3.6.1.4.1.258.5100.200.1.16.1.1.0' },
            { key: 'psuStatus', oid: '1.3.6.1.4.1.258.5100.200.1.16.3.1.0' },
            { key: 'raidStatus', oid: '1.3.6.1.4.1.258.5100.200.1.13.2.1.0' },
            { key: 'recordingState', oid: '1.3.6.1.4.1.258.5100.200.1.14.1.0' },
        ],
        hddSubtree: '1.3.6.1.4.1.258.5100.200.1.13.1',
        cameraSubtree: '1.3.6.1.4.1.258.5100.200.1.15',
        isNvr: true
    },
    hikvision: {
        id: 'hikvision',
        name: 'Hikvision',
        category: 'nvr',
        defaultMethod: 'snmp',
        aliases: ['hikvision', 'hik'],
        sysInfoOids: [
            { key: 'model', oid: '1.3.6.1.4.1.39165.1.1.0' },
            { key: 'serialNumber', oid: '1.3.6.1.4.1.39165.1.2.0' },
            { key: 'firmware', oid: '1.3.6.1.4.1.39165.1.3.0' },
        ],
        hddSubtree: '1.3.6.1.4.1.39165.1.4.1',
        cameraSubtree: '1.3.6.1.4.1.39165.1.5.1',
        isNvr: true
    },
    dahua: {
        id: 'dahua',
        name: 'Dahua Technology',
        category: 'nvr',
        defaultMethod: 'snmp',
        aliases: ['dahua', 'dh-'],
        sysInfoOids: [
            { key: 'model', oid: '1.3.6.1.4.1.10046.1.1.0' },
            { key: 'serialNumber', oid: '1.3.6.1.4.1.10046.1.2.0' },
        ],
        hddSubtree: '1.3.6.1.4.1.10046.1.3',
        cameraSubtree: '1.3.6.1.4.1.10046.1.4',
        isNvr: true
    },
    generic: {
        id: 'generic',
        name: 'Generic Device',
        category: 'endpoint',
        defaultMethod: 'tcp',
        aliases: ['generic', 'endpoint', 'server', 'windows', 'linux']
    }
};

/**
 * Mencocokkan input (vendor, type, hostname) dengan profil vendor
 */
export const resolveVendorProfile = (vendorStr = '', typeStr = '', hostnameStr = '', customProfiles = {}) => {
    const v = String(vendorStr || '').trim().toLowerCase();
    const t = String(typeStr || '').trim().toLowerCase();
    const h = String(hostnameStr || '').trim().toLowerCase();

    // Normalisasi menghapus dash, spasi, dan underscore untuk pencocokan toleran
    const vNorm = v.replace(/[-_\s]/g, '');
    const hNorm = h.replace(/[-_\s]/g, '');

    const allProfiles = { ...DEFAULT_VENDOR_PROFILES, ...customProfiles };

    // 0. Deteksi spesifik seri Panasonic / i-PRO berdasarkan model/vendor
    if (vNorm.includes('nx400') || vNorm.includes('nx300') || hNorm.includes('nx400') || hNorm.includes('nx300') || /wj[-_]?nx400/i.test(v) || /wj[-_]?nx400/i.test(h)) {
        return allProfiles.panasonic || DEFAULT_VENDOR_PROFILES.panasonic;
    }
    if (vNorm.includes('nx510') || vNorm.includes('nx410') || hNorm.includes('nx510') || hNorm.includes('nx410') || /wj[-_]?nx510/i.test(v) || /wj[-_]?nx510/i.test(h)) {
        return allProfiles.ipro || DEFAULT_VENDOR_PROFILES.ipro;
    }

    // 1. Prioritaskan kecocokan Merek (Vendor) dari data inventory
    for (const key of Object.keys(allProfiles)) {
        const profile = allProfiles[key];
        const aliases = profile.aliases || [key];
        if (v && aliases.some(alias => {
            const a = alias.toLowerCase();
            const aNorm = a.replace(/[-_\s]/g, '');
            return v.includes(a) || (aNorm && vNorm.includes(aNorm));
        })) {
            return profile;
        }
    }

    // 2. Jika field Vendor kosong, cocokkan hostname
    for (const key of Object.keys(allProfiles)) {
        const profile = allProfiles[key];
        const aliases = profile.aliases || [key];
        if (h && aliases.some(alias => {
            const a = alias.toLowerCase();
            const aNorm = a.replace(/[-_\s]/g, '');
            return h.includes(a) || (aNorm && hNorm.includes(aNorm));
        })) {
            return profile;
        }
    }

    // 3. Fallback berdasarkan jenis perangkat
    if (t.includes('nvr') || t.includes('cctv') || h.includes('nvr') || h.includes('cam')) {
        return {
            ...DEFAULT_VENDOR_PROFILES.ipro,
            name: vendorStr || 'Generic NVR / CCTV',
            id: 'nvr_generic'
        };
    }

    if (t.includes('switch') || h.includes('sw-') || h.includes('switch')) {
        return {
            ...DEFAULT_VENDOR_PROFILES.cisco,
            name: vendorStr || 'Generic Switch',
            id: 'switch_generic'
        };
    }

    if (t.includes('router')) {
        return {
            ...DEFAULT_VENDOR_PROFILES.mikrotik,
            name: vendorStr || 'Generic Router',
            id: 'router_generic'
        };
    }

    return DEFAULT_VENDOR_PROFILES.generic;
};
