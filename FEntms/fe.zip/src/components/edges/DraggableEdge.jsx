import React, { useRef, useState, useEffect, useCallback } from 'react';
import { BaseEdge, EdgeLabelRenderer, useReactFlow, useStore } from 'reactflow';
import { showConfirm } from '../../utils/swal';

// Helper fungsi rute ortogonal standar bawaan (default points)
export const getDefaultOrthogonalPoints = (sourceX, sourceY, targetX, targetY, sourcePosition = 'bottom', targetPosition = 'top') => {
    if (sourceX === undefined || sourceY === undefined || targetX === undefined || targetY === undefined) return [];

    const isSourceVert = sourcePosition === 'top' || sourcePosition === 'bottom';
    const isTargetVert = targetPosition === 'top' || targetPosition === 'bottom';

    if (isSourceVert && isTargetVert) {
        // Jika kedua handle vertikal dan berlawanan arah yang wajar (source keluar ke bawah, target masuk dari atas)
        if (sourcePosition === 'bottom' && targetPosition === 'top' && targetY > sourceY + 20) {
            const midY = (sourceY + targetY) / 2;
            return [
                { x: sourceX, y: sourceY },
                { x: sourceX, y: midY },
                { x: targetX, y: midY },
                { x: targetX, y: targetY }
            ];
        }
        if (sourcePosition === 'top' && targetPosition === 'bottom' && sourceY > targetY + 20) {
            const midY = (sourceY + targetY) / 2;
            return [
                { x: sourceX, y: sourceY },
                { x: sourceX, y: midY },
                { x: targetX, y: midY },
                { x: targetX, y: targetY }
            ];
        }
        // Jika target berada di belakang/sejajar arah source handle
        const stubOffset = 25;
        const sOutY = sourcePosition === 'bottom' ? sourceY + stubOffset : sourceY - stubOffset;
        const tInY = targetPosition === 'top' ? targetY - stubOffset : targetY + stubOffset;
        const midX = (sourceX + targetX) / 2;
        return [
            { x: sourceX, y: sourceY },
            { x: sourceX, y: sOutY },
            { x: midX, y: sOutY },
            { x: midX, y: tInY },
            { x: targetX, y: tInY },
            { x: targetX, y: targetY }
        ];
    }

    if (!isSourceVert && !isTargetVert) {
        if (sourcePosition === 'right' && targetPosition === 'left' && targetX > sourceX + 20) {
            const midX = (sourceX + targetX) / 2;
            return [
                { x: sourceX, y: sourceY },
                { x: midX, y: sourceY },
                { x: midX, y: targetY },
                { x: targetX, y: targetY }
            ];
        }
        const stubOffset = 25;
        const sOutX = sourcePosition === 'right' ? sourceX + stubOffset : sourceX - stubOffset;
        const tInX = targetPosition === 'left' ? targetX - stubOffset : targetX + stubOffset;
        const midY = (sourceY + targetY) / 2;
        return [
            { x: sourceX, y: sourceY },
            { x: sOutX, y: sourceY },
            { x: sOutX, y: midY },
            { x: tInX, y: midY },
            { x: tInX, y: targetY },
            { x: targetX, y: targetY }
        ];
    }

    if (isSourceVert && !isTargetVert) {
        return [
            { x: sourceX, y: sourceY },
            { x: sourceX, y: targetY },
            { x: targetX, y: targetY }
        ];
    }

    return [
        { x: sourceX, y: sourceY },
        { x: targetX, y: sourceY },
        { x: targetX, y: targetY }
    ];
};

// Helper untuk mengadaptasi titik kontrol kustom saat node source atau target dipindahkan
export const adaptControlPoints = (controlPoints, sourceX, sourceY, targetX, targetY, sourceAnchor, targetAnchor) => {
    if (!controlPoints || controlPoints.length === 0) return [];
    if (!sourceAnchor || !targetAnchor) return controlPoints;

    const deltaSX = sourceX - sourceAnchor.x;
    const deltaSY = sourceY - sourceAnchor.y;
    const deltaTX = targetX - targetAnchor.x;
    const deltaTY = targetY - targetAnchor.y;

    // Jika source dan target tidak berpindah dari anchor dasarnya, titik tetap
    if (Math.abs(deltaSX) < 0.1 && Math.abs(deltaSY) < 0.1 && Math.abs(deltaTX) < 0.1 && Math.abs(deltaTY) < 0.1) {
        return controlPoints;
    }

    const baseDist = Math.hypot(targetAnchor.x - sourceAnchor.x, targetAnchor.y - sourceAnchor.y) || 1;

    return controlPoints.map((cp, idx) => {
        // Hitung faktor interpolasi t (0 = dekat source, 1 = dekat target)
        // Gabungkan rasio indeks titik dan rasio jarak terhadap garis source->target
        const indexT = (idx + 1) / (controlPoints.length + 1);
        
        const distFromSource = Math.hypot(cp.x - sourceAnchor.x, cp.y - sourceAnchor.y);
        const distFromTarget = Math.hypot(cp.x - targetAnchor.x, cp.y - targetAnchor.y);
        const totalDist = distFromSource + distFromTarget;
        const distT = totalDist > 0 ? (distFromSource / totalDist) : indexT;

        // Bobot gabungan yang halus
        const t = Math.max(0, Math.min(1, (indexT + distT) / 2));

        // Hitung pergeseran proporsional
        const shiftX = (1 - t) * deltaSX + t * deltaTX;
        const shiftY = (1 - t) * deltaSY + t * deltaTY;

        return {
            x: cp.x + shiftX,
            y: cp.y + shiftY
        };
    });
};

// Helper untuk menghasilkan rute ortogonal lengkap yang adaptif terhadap source, target, dan titik kontrol kustom
const getFullOrthogonalRoute = (sourceX, sourceY, targetX, targetY, controlPoints = [], sourcePosition = 'bottom', targetPosition = 'top') => {
    if (sourceX === undefined || sourceY === undefined || targetX === undefined || targetY === undefined) return [];

    // Jika tidak ada titik kontrol kustom, gunakan rute standar yang rapi
    if (!controlPoints || controlPoints.length === 0) {
        return getDefaultOrthogonalPoints(sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition);
    }

    const isSourceVert = sourcePosition === 'top' || sourcePosition === 'bottom';
    const isTargetVert = targetPosition === 'top' || targetPosition === 'bottom';

    // Hubungkan titik-titik kontrol secara ortogonal adaptif
    const rawKeyPoints = [{ x: sourceX, y: sourceY }, ...controlPoints, { x: targetX, y: targetY }];
    const route = [rawKeyPoints[0]];

    for (let i = 0; i < rawKeyPoints.length - 1; i++) {
        const from = rawKeyPoints[i];
        const to = rawKeyPoints[i + 1];

        const isCurrentHoriz = Math.abs(from.y - to.y) < 1.5;
        const isCurrentVert = Math.abs(from.x - to.x) < 1.5;

        // Jika sudah sejajar, langsung sambung
        if (isCurrentHoriz || isCurrentVert) {
            route.push(to);
        } else {
            // Jika miring/belum sejajar, bentuk sudut L ortogonal otomatis
            if (i === 0) {
                // Dari source: ikuti arah keluar port source
                if (isSourceVert) {
                    route.push({ x: from.x, y: to.y });
                } else {
                    route.push({ x: to.x, y: from.y });
                }
            } else if (i === rawKeyPoints.length - 2) {
                // Menuju target: ikuti arah masuk port target
                if (isTargetVert) {
                    route.push({ x: to.x, y: from.y });
                } else {
                    route.push({ x: from.x, y: to.y });
                }
            } else {
                // Di antara titik kontrol tengah: belokan ortogonal halus
                route.push({ x: to.x, y: from.y });
            }
            route.push(to);
        }
    }

    // Hilangkan titik-titik redundan/berimpit segaris
    const cleaned = [];
    for (let i = 0; i < route.length; i++) {
        if (cleaned.length === 0) {
            cleaned.push(route[i]);
        } else {
            const prev = cleaned[cleaned.length - 1];
            const dist = Math.hypot(route[i].x - prev.x, route[i].y - prev.y);
            if (dist > 1.5) {
                cleaned.push(route[i]);
            }
        }
    }

    return cleaned;
};

// Helper untuk mengambil seluruh titik segmen suatu edge
const getEdgeSegments = (edge) => {
    const cps = edge.data?.controlPoints || (edge.data?.controlPoint ? [edge.data.controlPoint] : []);
    const sourceAnchor = edge.data?.sourceAnchor;
    const targetAnchor = edge.data?.targetAnchor;
    const adaptedCps = adaptControlPoints(cps, edge.sourceX, edge.sourceY, edge.targetX, edge.targetY, sourceAnchor, targetAnchor);
    return getFullOrthogonalRoute(
        edge.sourceX,
        edge.sourceY,
        edge.targetX,
        edge.targetY,
        adaptedCps,
        edge.sourcePosition,
        edge.targetPosition
    );
};

// Algoritma pembentuk SVG Path dengan Corner Radius Halus (Rounded Corners) & Jembatan Lengkung (Arc Bridge)
const buildPathWithBridgesAndCorners = (currentEdgeId, currentPoints, allEdges, cornerRadius = 6, bridgeRadius = 8) => {
    if (!currentPoints || currentPoints.length < 2) return '';

    const otherSegments = [];
    if (Array.isArray(allEdges) && allEdges.length > 1) {
        allEdges.forEach(otherEdge => {
            if (otherEdge.id === currentEdgeId) return;
            const otherPts = getEdgeSegments(otherEdge);
            if (!otherPts || otherPts.length < 2) return;
            for (let j = 0; j < otherPts.length - 1; j++) {
                otherSegments.push({
                    p1: otherPts[j],
                    p2: otherPts[j+1],
                    edgeId: otherEdge.id,
                    isHorizontal: Math.abs(otherPts[j].y - otherPts[j+1].y) < 1.5,
                    isVertical: Math.abs(otherPts[j].x - otherPts[j+1].x) < 1.5
                });
            }
        });
    }

    let path = `M ${currentPoints[0].x.toFixed(1)},${currentPoints[0].y.toFixed(1)}`;

    for (let i = 0; i < currentPoints.length - 1; i++) {
        const p1 = currentPoints[i];
        const p2 = currentPoints[i+1];
        const dx = p2.x - p1.x;
        const dy = p2.y - p1.y;
        const segLen = Math.hypot(dx, dy);

        if (segLen < 1) continue;

        const isCurrentHoriz = Math.abs(dy) < 1.5;
        const isCurrentVert = Math.abs(dx) < 1.5;

        // Cari perpotongan dengan garis lain untuk jembatan busur
        const intersections = [];

        if (otherSegments.length > 0) {
            otherSegments.forEach(otherSeg => {
                let currentHasPriority = false;
                if (isCurrentHoriz && otherSeg.isVertical) {
                    currentHasPriority = true;
                } else if (isCurrentVert && otherSeg.isHorizontal) {
                    currentHasPriority = false;
                } else {
                    currentHasPriority = String(currentEdgeId) > String(otherSeg.edgeId);
                }

                if (!currentHasPriority) return;

                const d = (p2.x - p1.x) * (otherSeg.p2.y - otherSeg.p1.y) - (p2.y - p1.y) * (otherSeg.p2.x - otherSeg.p1.x);
                if (Math.abs(d) < 1e-4) return;

                const t = ((otherSeg.p1.x - p1.x) * (otherSeg.p2.y - otherSeg.p1.y) - (otherSeg.p1.y - p1.y) * (otherSeg.p2.x - otherSeg.p1.x)) / d;
                const u = ((otherSeg.p1.x - p1.x) * (p2.y - p1.y) - (otherSeg.p1.y - p1.y) * (p2.x - p1.x)) / d;

                if (t > 0.05 && t < 0.95 && u > 0.05 && u < 0.95) {
                    const distFromStart = t * segLen;
                    if (distFromStart > bridgeRadius + cornerRadius + 2 && distFromStart < segLen - bridgeRadius - cornerRadius - 2) {
                        intersections.push({
                            t,
                            dist: distFromStart,
                            x: p1.x + t * dx,
                            y: p1.y + t * dy
                        });
                    }
                }
            });
        }

        intersections.sort((a, b) => a.dist - b.dist);

        const validIntersections = [];
        intersections.forEach(inter => {
            if (validIntersections.length === 0 || (inter.dist - validIntersections[validIntersections.length - 1].dist) > bridgeRadius * 2 + 4) {
                validIntersections.push(inter);
            }
        });

        const ux = dx / segLen;
        const uy = dy / segLen;

        // Render jembatan pada segmen saat ini
        validIntersections.forEach(inter => {
            const startBridgeX = inter.x - bridgeRadius * ux;
            const startBridgeY = inter.y - bridgeRadius * uy;
            const endBridgeX = inter.x + bridgeRadius * ux;
            const endBridgeY = inter.y + bridgeRadius * uy;

            path += ` L ${startBridgeX.toFixed(1)},${startBridgeY.toFixed(1)}`;
            path += ` A ${bridgeRadius} ${bridgeRadius} 0 0 0 ${endBridgeX.toFixed(1)},${endBridgeY.toFixed(1)}`;
        });

        // Corner rounding jika ada segmen berikutnya
        const nextPoint = currentPoints[i + 2];
        if (nextPoint && cornerRadius > 0) {
            const nextDx = nextPoint.x - p2.x;
            const nextDy = nextPoint.y - p2.y;
            const nextSegLen = Math.hypot(nextDx, nextDy);
            const effRadius = Math.min(cornerRadius, segLen / 2, nextSegLen / 2);

            if (effRadius > 1.5) {
                const cornerStartX = p2.x - effRadius * ux;
                const cornerStartY = p2.y - effRadius * uy;
                const nextUx = nextDx / nextSegLen;
                const nextUy = nextDy / nextSegLen;
                const cornerEndX = p2.x + effRadius * nextUx;
                const cornerEndY = p2.y + effRadius * nextUy;

                path += ` L ${cornerStartX.toFixed(1)},${cornerStartY.toFixed(1)}`;
                path += ` Q ${p2.x.toFixed(1)},${p2.y.toFixed(1)} ${cornerEndX.toFixed(1)},${cornerEndY.toFixed(1)}`;
                continue;
            }
        }

        path += ` L ${p2.x.toFixed(1)},${p2.y.toFixed(1)}`;
    }

    return path;
};

export default function DraggableEdge(props) {
    const { id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, style, markerEnd, data, selected } = props;
    const { setEdges, screenToFlowPosition } = useReactFlow();
    const zoom = useStore((s) => s.transform[2]);
    const allEdges = useStore((s) => s.edges);

    const [isHovered, setIsHovered] = useState(false);

    // Titik kontrol kustom yang tersimpan di data edge beserta anchor koordinat dasarnya
    const rawCps = data?.controlPoints || (data?.controlPoint ? [data.controlPoint] : []);
    const sourceAnchor = data?.sourceAnchor || { x: sourceX, y: sourceY };
    const targetAnchor = data?.targetAnchor || { x: targetX, y: targetY };

    const [localCps, setLocalCps] = useState(rawCps);
    const [localSourceAnchor, setLocalSourceAnchor] = useState(sourceAnchor);
    const [localTargetAnchor, setLocalTargetAnchor] = useState(targetAnchor);

    useEffect(() => {
        setLocalCps(rawCps);
        setLocalSourceAnchor(data?.sourceAnchor || { x: sourceX, y: sourceY });
        setLocalTargetAnchor(data?.targetAnchor || { x: targetX, y: targetY });
    }, [JSON.stringify(rawCps), data?.sourceAnchor?.x, data?.sourceAnchor?.y, data?.targetAnchor?.x, data?.targetAnchor?.y]);

    const commitControlPoints = useCallback((newCps) => {
        const curSourceAnchor = { x: sourceX, y: sourceY };
        const curTargetAnchor = { x: targetX, y: targetY };
        setLocalCps(newCps);
        setLocalSourceAnchor(curSourceAnchor);
        setLocalTargetAnchor(curTargetAnchor);
        if (data) {
            data.controlPoints = newCps;
            data.sourceAnchor = curSourceAnchor;
            data.targetAnchor = curTargetAnchor;
        }
        setEdges((eds) => eds.map(edge => edge.id === id ? { 
            ...edge, 
            data: { 
                ...edge.data, 
                controlPoints: newCps,
                sourceAnchor: curSourceAnchor,
                targetAnchor: curTargetAnchor
            } 
        } : edge));
    }, [data, id, setEdges, sourceX, sourceY, targetX, targetY]);

    // Adaptasi titik kontrol kustom terhadap pergeseran posisi node live
    const effectiveCps = adaptControlPoints(
        localCps,
        sourceX,
        sourceY,
        targetX,
        targetY,
        localSourceAnchor,
        localTargetAnchor
    );

    // Titik-titik pembentuk rute garis lengkap yang adaptif terhadap posisi node & titik kontrol
    const currentPoints = getFullOrthogonalRoute(
        sourceX,
        sourceY,
        targetX,
        targetY,
        effectiveCps,
        sourcePosition,
        targetPosition
    );

    // SVG path utama dengan corner rounding halus dan jembatan lengkung
    const path = buildPathWithBridgesAndCorners(id, currentPoints, allEdges, 8, 8);

    // Hitung posisi tengah garis untuk tombol putus koneksi (Disconnect Button)
    const midSegmentIndex = Math.floor((currentPoints.length - 1) / 2);
    const pA = currentPoints[midSegmentIndex] || currentPoints[0];
    const pB = currentPoints[midSegmentIndex + 1] || currentPoints[currentPoints.length - 1];
    const centerEdgeX = (pA.x + pB.x) / 2;
    const centerEdgeY = (pA.y + pB.y) / 2;

    // Trigger putus koneksi via dialog konfirmasi
    const handleDisconnect = (e) => {
        e.stopPropagation();
        e.preventDefault();
        showConfirm('Putus Koneksi?', 'Apakah Anda yakin ingin memutus koneksi antara perangkat ini?', 'Ya, Putuskan')
        .then((result) => {
            if (result.isConfirmed) {
                setEdges((eds) => eds.filter((e) => e.id !== id));
            }
        });
    };

    // Double-click pada garis untuk menambahkan titik kontrol baru
    const handlePathDoubleClick = (e) => {
        e.stopPropagation();
        e.preventDefault();

        const flowPos = screenToFlowPosition({ x: e.clientX, y: e.clientY });
        if (!flowPos) return;
        const clickX = flowPos.x;
        const clickY = flowPos.y;

        let insertIdx = 0;
        let minDist = Infinity;
        for (let i = 0; i < currentPoints.length - 1; i++) {
            const p1 = currentPoints[i];
            const p2 = currentPoints[i + 1];
            const dx = p2.x - p1.x;
            const dy = p2.y - p1.y;
            const l2 = dx * dx + dy * dy;
            let t = l2 === 0 ? 0 : ((clickX - p1.x) * dx + (clickY - p1.y) * dy) / l2;
            t = Math.max(0, Math.min(1, t));
            const projX = p1.x + t * dx;
            const projY = p1.y + t * dy;
            const dist = Math.hypot(clickX - projX, clickY - projY);
            if (dist < minDist) {
                minDist = dist;
                insertIdx = i;
            }
        }

        const basePoints = currentPoints.slice(1, -1).map(p => ({ ...p }));
        basePoints.splice(Math.max(0, insertIdx - 1), 0, { x: clickX, y: clickY });
        commitControlPoints(basePoints);
    };

    // Handler untuk drag langsung pada segmen garis (Direct Segment Drag)
    const handleSegmentDragStart = (e, segIndex) => {
        if (e.button !== 0) return; // Hanya klik kiri
        e.stopPropagation();
        e.preventDefault();

        const startClientX = e.clientX;
        const startClientY = e.clientY;
        const currentZoom = zoom || 1;

        const initialPoints = currentPoints.map(p => ({ ...p }));
        const p1 = initialPoints[segIndex];
        const p2 = initialPoints[segIndex + 1];
        if (!p1 || !p2) return;

        const isHoriz = Math.abs(p1.y - p2.y) < 2;

        const handlePointerMove = (moveEvent) => {
            moveEvent.stopPropagation();
            moveEvent.preventDefault();

            const deltaX = (moveEvent.clientX - startClientX) / currentZoom;
            const deltaY = (moveEvent.clientY - startClientY) / currentZoom;

            const updated = initialPoints.map(p => ({ ...p }));

            if (isHoriz) {
                // Segmen horizontal digeser secara vertikal (Y)
                if (segIndex > 0) updated[segIndex].y = p1.y + deltaY;
                if (segIndex + 1 < updated.length - 1) updated[segIndex + 1].y = p2.y + deltaY;
                // Jika segmen ujung yang digeser, buat titik belok baru agar tidak miring
                if (segIndex === 0) {
                    updated.splice(1, 0, { x: p1.x, y: p1.y + deltaY });
                } else if (segIndex + 1 === updated.length - 1) {
                    updated.splice(updated.length - 1, 0, { x: p2.x, y: p2.y + deltaY });
                }
            } else {
                // Segmen vertikal digeser secara horizontal (X)
                if (segIndex > 0) updated[segIndex].x = p1.x + deltaX;
                if (segIndex + 1 < updated.length - 1) updated[segIndex + 1].x = p2.x + deltaX;
                // Jika segmen ujung yang digeser, buat titik belok baru agar tidak miring
                if (segIndex === 0) {
                    updated.splice(1, 0, { x: p1.x + deltaX, y: p1.y });
                } else if (segIndex + 1 === updated.length - 1) {
                    updated.splice(updated.length - 1, 0, { x: p2.x + deltaX, y: p2.y });
                }
            }

            const newCps = updated.slice(1, -1);
            setLocalCps(newCps);
        };

        const handlePointerUp = (upEvent) => {
            upEvent.stopPropagation();
            upEvent.preventDefault();

            window.removeEventListener('pointermove', handlePointerMove, true);
            window.removeEventListener('pointerup', handlePointerUp, true);
            window.removeEventListener('pointercancel', handlePointerUp, true);

            const deltaX = (upEvent.clientX - startClientX) / currentZoom;
            const deltaY = (upEvent.clientY - startClientY) / currentZoom;

            const updated = initialPoints.map(p => ({ ...p }));
            if (isHoriz) {
                if (segIndex > 0) updated[segIndex].y = p1.y + deltaY;
                if (segIndex + 1 < updated.length - 1) updated[segIndex + 1].y = p2.y + deltaY;
                if (segIndex === 0) {
                    updated.splice(1, 0, { x: p1.x, y: p1.y + deltaY });
                } else if (segIndex + 1 === updated.length - 1) {
                    updated.splice(updated.length - 1, 0, { x: p2.x, y: p2.y + deltaY });
                }
            } else {
                if (segIndex > 0) updated[segIndex].x = p1.x + deltaX;
                if (segIndex + 1 < updated.length - 1) updated[segIndex + 1].x = p2.x + deltaX;
                if (segIndex === 0) {
                    updated.splice(1, 0, { x: p1.x + deltaX, y: p1.y });
                } else if (segIndex + 1 === updated.length - 1) {
                    updated.splice(updated.length - 1, 0, { x: p2.x + deltaX, y: p2.y });
                }
            }

            const newCps = updated.slice(1, -1);
            commitControlPoints(newCps);
        };

        window.addEventListener('pointermove', handlePointerMove, { capture: true, passive: false });
        window.addEventListener('pointerup', handlePointerUp, { capture: true, passive: false });
        window.addEventListener('pointercancel', handlePointerUp, { capture: true, passive: false });
    };

    // Segmen-segmen interaktif untuk pergeseran garis langsung
    const interactiveSegments = [];
    for (let i = 0; i < currentPoints.length - 1; i++) {
        const p1 = currentPoints[i];
        const p2 = currentPoints[i + 1];
        const isHoriz = Math.abs(p1.y - p2.y) < 2;
        interactiveSegments.push({
            p1,
            p2,
            index: i,
            isHoriz,
            path: `M ${p1.x},${p1.y} L ${p2.x},${p2.y}`,
            midX: (p1.x + p2.x) / 2,
            midY: (p1.y + p2.y) / 2
        });
    }

    const isConnectedSelected = data?.isConnectedSelected;
    const isActive = isHovered || selected;

    return (
        <g 
            className="group/edge-wrapper"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            {/* Garis Dasar Berwarna (Base Edge) dengan Gradient & Glow Halus */}
            <BaseEdge 
                path={path} 
                markerEnd={markerEnd} 
                interactionWidth={isConnectedSelected ? 6 : 4}
                style={{
                    ...style,
                    stroke: isConnectedSelected ? '#f43f5e' : (isActive ? '#38bdf8' : (style?.stroke || '#3b82f6')),
                    strokeWidth: isConnectedSelected ? 3.5 : (isActive ? 3 : (style?.strokeWidth || 2)),
                    strokeLinecap: 'round',
                    strokeLinejoin: 'round',
                    filter: isConnectedSelected 
                        ? 'drop-shadow(0 0 10px rgba(244, 63, 94, 0.9))' 
                        : (isActive ? 'drop-shadow(0 0 8px rgba(56, 189, 248, 0.75))' : 'drop-shadow(0 0 2px rgba(59, 130, 246, 0.3))'),
                    animation: isConnectedSelected ? 'edge-pulse-red 0.9s infinite ease-in-out' : undefined,
                    transition: 'stroke 0.2s ease, stroke-width 0.15s ease, filter 0.2s ease'
                }} 
            />
            
            {/* Fat Paths Interaktif per Segmen untuk Direct Drag Garis */}
            {interactiveSegments.map((seg) => (
                <path
                    key={`seg-${seg.index}`}
                    d={seg.path}
                    fill="none"
                    stroke="transparent"
                    strokeWidth={24}
                    className="cursor-grab active:cursor-grabbing hover:stroke-cyan-400/20"
                    style={{ pointerEvents: 'stroke', touchAction: 'none' }}
                    onPointerDown={(e) => handleSegmentDragStart(e, seg.index)}
                    onDoubleClick={handlePathDoubleClick}
                    title="Klik & geser untuk memindahkan garis, double-click untuk tambah titik belok"
                />
            ))}

            <EdgeLabelRenderer>
                {/* Tombol Putus Koneksi (Tanda Silang Merah) Floating di Atas Garis saat Edge Aktif / Hover / Selected */}
                {isActive && (
                    <div
                        style={{
                            position: 'absolute',
                            transform: `translate(-50%, -100%) translate(${centerEdgeX}px,${centerEdgeY - 8}px)`,
                            pointerEvents: 'all',
                            zIndex: 1000
                        }}
                        className="nodrag nopan select-none group/disconnect"
                    >
                        <button
                            type="button"
                            onClick={handleDisconnect}
                            title="Putuskan Koneksi"
                            className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-slate-900/95 hover:bg-rose-600 text-rose-400 hover:text-white border border-rose-500/80 shadow-[0_0_12px_rgba(244,63,94,0.6)] hover:scale-110 transition-all duration-150 cursor-pointer text-[10px] font-semibold tracking-wider"
                        >
                            <svg className="w-3.5 h-3.5 stroke-[2.5]" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                            <span className="pr-0.5">Putus</span>
                        </button>
                    </div>
                )}

                {/* Render Handle Titik Belok yang Tersimpan (Cyan Circle) */}
                {effectiveCps.map((cp, idx) => (
                    <ControlPointHandle
                        key={`cp-${idx}`}
                        pointX={cp.x} 
                        pointY={cp.y}
                        zoom={zoom}
                        onDragLive={(newX, newY) => {
                            const updated = [...effectiveCps];
                            if (updated[idx]) {
                                updated[idx] = { x: newX, y: newY };
                                setLocalCps(updated);
                                setLocalSourceAnchor({ x: sourceX, y: sourceY });
                                setLocalTargetAnchor({ x: targetX, y: targetY });
                            }
                        }}
                        onDragEnd={(newX, newY) => {
                            const updated = [...effectiveCps];
                            if (updated[idx]) {
                                updated[idx] = { x: newX, y: newY };
                                commitControlPoints(updated);
                            }
                        }}
                        onDoubleClick={() => {
                            const newCps = effectiveCps.filter((_, i) => i !== idx);
                            commitControlPoints(newCps);
                        }}
                    />
                ))}

                {/* Render Handle Penambahan Titik di Tengah Segmen saat Hover/Select (Hijau Circle) */}
                {isActive && interactiveSegments.map((seg) => (
                    <MidpointHandle
                        key={`mid-${seg.index}`}
                        pointX={seg.midX}
                        pointY={seg.midY}
                        zoom={zoom}
                        onDragStart={(startPoint) => {
                            const basePoints = effectiveCps.length > 0
                                ? [...effectiveCps]
                                : getDefaultOrthogonalPoints(sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition).slice(1, -1);
                            basePoints.splice(seg.index, 0, startPoint);
                            setLocalCps(basePoints);
                            setLocalSourceAnchor({ x: sourceX, y: sourceY });
                            setLocalTargetAnchor({ x: targetX, y: targetY });
                            return seg.index;
                        }}
                        onDragLive={(insertedIdx, newX, newY) => {
                            setLocalCps(prev => {
                                const next = [...prev];
                                if (next[insertedIdx]) {
                                    next[insertedIdx] = { x: newX, y: newY };
                                }
                                return next;
                            });
                        }}
                        onDragEnd={(insertedIdx, newX, newY) => {
                            setLocalCps(prev => {
                                const next = [...prev];
                                if (next[insertedIdx]) {
                                    next[insertedIdx] = { x: newX, y: newY };
                                }
                                commitControlPoints(next);
                                return next;
                            });
                        }}
                    />
                ))}
            </EdgeLabelRenderer>
        </g>
    );
}

// Komponen Handle Titik Belok Kustom (Cyan)
function ControlPointHandle({ pointX, pointY, zoom = 1, onDragLive, onDragEnd, onDoubleClick }) {
    const dragDataRef = useRef(null);
    const [isHovered, setIsHovered] = useState(false);

    const handlePointerDown = (e) => {
        if (e.button !== 0) return;
        e.stopPropagation();
        e.preventDefault();

        const startClientX = e.clientX;
        const startClientY = e.clientY;
        const startPointX = pointX;
        const startPointY = pointY;
        const currentZoom = zoom || 1;

        dragDataRef.current = {
            startX: startClientX,
            startY: startClientY,
            origX: startPointX,
            origY: startPointY,
            currentX: startPointX,
            currentY: startPointY
        };

        const handlePointerMove = (moveEvent) => {
            if (!dragDataRef.current) return;
            moveEvent.stopPropagation();
            moveEvent.preventDefault();

            const deltaX = (moveEvent.clientX - dragDataRef.current.startX) / currentZoom;
            const deltaY = (moveEvent.clientY - dragDataRef.current.startY) / currentZoom;

            const nextX = dragDataRef.current.origX + deltaX;
            const nextY = dragDataRef.current.origY + deltaY;

            dragDataRef.current.currentX = nextX;
            dragDataRef.current.currentY = nextY;

            if (onDragLive) onDragLive(nextX, nextY);
        };

        const handlePointerUp = (upEvent) => {
            upEvent.stopPropagation();
            upEvent.preventDefault();

            window.removeEventListener('pointermove', handlePointerMove, true);
            window.removeEventListener('pointerup', handlePointerUp, true);
            window.removeEventListener('pointercancel', handlePointerUp, true);

            if (dragDataRef.current) {
                const finalX = dragDataRef.current.currentX;
                const finalY = dragDataRef.current.currentY;
                dragDataRef.current = null;
                if (onDragEnd) onDragEnd(finalX, finalY);
            }
        };

        window.addEventListener('pointermove', handlePointerMove, { capture: true, passive: false });
        window.addEventListener('pointerup', handlePointerUp, { capture: true, passive: false });
        window.addEventListener('pointercancel', handlePointerUp, { capture: true, passive: false });
    };

    return (
        <div
            style={{
                position: 'absolute',
                transform: `translate(-50%, -50%) translate(${pointX}px,${pointY}px)`,
                pointerEvents: 'all',
                cursor: 'grab',
                zIndex: 50,
                touchAction: 'none'
            }}
            className="nodrag nopan select-none"
            onPointerDown={handlePointerDown}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onClick={(e) => e.stopPropagation()}
            onDoubleClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                if (onDoubleClick) onDoubleClick();
            }}
            title="Tarik untuk geser posisi titik, Double-click untuk hapus titik"
        >
            <div className={`rounded-full border-2 border-white bg-cyan-400 shadow-[0_0_12px_#06b6d4] transition-all duration-100 flex items-center justify-center ${
                isHovered ? 'w-5 h-5 scale-125' : 'w-4 h-4 scale-100'
            }`} />
        </div>
    );
}

// Komponen Handle Titik Tengah Segmen untuk Menambah Titik Belok Baru (Hijau)
function MidpointHandle({ pointX, pointY, zoom = 1, onDragStart, onDragLive, onDragEnd }) {
    const dragDataRef = useRef(null);
    const [isHovered, setIsHovered] = useState(false);

    const handlePointerDown = (e) => {
        if (e.button !== 0) return;
        e.stopPropagation();
        e.preventDefault();

        const startClientX = e.clientX;
        const startClientY = e.clientY;
        const startPointX = pointX;
        const startPointY = pointY;
        const currentZoom = zoom || 1;

        let insertedIdx = 0;
        if (onDragStart) {
            insertedIdx = onDragStart({ x: startPointX, y: startPointY });
        }

        dragDataRef.current = {
            startX: startClientX,
            startY: startClientY,
            origX: startPointX,
            origY: startPointY,
            currentX: startPointX,
            currentY: startPointY,
            insertedIdx
        };

        const handlePointerMove = (moveEvent) => {
            if (!dragDataRef.current) return;
            moveEvent.stopPropagation();
            moveEvent.preventDefault();

            const deltaX = (moveEvent.clientX - dragDataRef.current.startX) / currentZoom;
            const deltaY = (moveEvent.clientY - dragDataRef.current.startY) / currentZoom;

            const nextX = dragDataRef.current.origX + deltaX;
            const nextY = dragDataRef.current.origY + deltaY;

            dragDataRef.current.currentX = nextX;
            dragDataRef.current.currentY = nextY;

            if (onDragLive) {
                onDragLive(dragDataRef.current.insertedIdx, nextX, nextY);
            }
        };

        const handlePointerUp = (upEvent) => {
            upEvent.stopPropagation();
            upEvent.preventDefault();

            window.removeEventListener('pointermove', handlePointerMove, true);
            window.removeEventListener('pointerup', handlePointerUp, true);
            window.removeEventListener('pointercancel', handlePointerUp, true);

            if (dragDataRef.current) {
                const finalX = dragDataRef.current.currentX;
                const finalY = dragDataRef.current.currentY;
                const idx = dragDataRef.current.insertedIdx;
                dragDataRef.current = null;
                if (onDragEnd) {
                    onDragEnd(idx, finalX, finalY);
                }
            }
        };

        window.addEventListener('pointermove', handlePointerMove, { capture: true, passive: false });
        window.addEventListener('pointerup', handlePointerUp, { capture: true, passive: false });
        window.addEventListener('pointercancel', handlePointerUp, { capture: true, passive: false });
    };

    return (
        <div
            style={{
                position: 'absolute',
                transform: `translate(-50%, -50%) translate(${pointX}px,${pointY}px)`,
                pointerEvents: 'all',
                cursor: 'pointer',
                zIndex: 40,
                touchAction: 'none'
            }}
            className="nodrag nopan select-none opacity-80 hover:opacity-100"
            onPointerDown={handlePointerDown}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onClick={(e) => e.stopPropagation()}
            title="Tarik titik hijau ini untuk membelokkan garis"
        >
            <div className={`rounded-full border border-emerald-100 bg-emerald-400 shadow-[0_0_8px_#10b981] transition-all duration-100 flex items-center justify-center ${
                isHovered ? 'w-4 h-4 scale-125' : 'w-3 h-3 scale-100'
            }`} />
        </div>
    );
}

