import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';
import { Network, MapPin, Activity } from 'lucide-react';

function CustomDeviceNode({ data, selected }) {
    const isWarning = data.status === 'warning';
    const isDown = data.status === 'down';

    let borderColor = 'border-emerald-500/30 group-hover:border-emerald-400/60';
    let bgGradient = 'from-slate-900/90 to-slate-950/90';
    let badgeColor = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    let iconBg = 'bg-emerald-500/10 border-emerald-500/20';
    let iconColor = 'text-emerald-400';
    let glowShadow = 'shadow-[0_0_20px_rgba(16,185,129,0.1)]';

    if (isDown) {
        borderColor = 'border-rose-500/50 group-hover:border-rose-400/80';
        bgGradient = 'from-rose-950/80 to-slate-950/90';
        badgeColor = 'bg-rose-500/10 text-rose-400 border-rose-500/30 font-bold';
        iconBg = 'bg-rose-500/20 border-rose-500/30';
        iconColor = 'text-rose-400';
        glowShadow = 'shadow-[0_0_20px_rgba(244,63,94,0.2)]';
    } else if (isWarning) {
        borderColor = 'border-amber-500/50 group-hover:border-amber-400/80';
        bgGradient = 'from-amber-950/80 to-slate-950/90';
        badgeColor = 'bg-amber-500/10 text-amber-400 border-amber-500/20';
        iconBg = 'bg-amber-500/20 border-amber-500/30';
        iconColor = 'text-amber-400';
        glowShadow = 'shadow-[0_0_20px_rgba(245,158,11,0.15)]';
    } else if (data.vlan?.includes('CCTV')) {
        borderColor = 'border-purple-500/40 group-hover:border-purple-400/70';
        bgGradient = 'from-purple-950/60 to-slate-950/90';
        badgeColor = 'bg-purple-500/10 text-purple-400 border-purple-500/20';
        iconBg = 'bg-purple-500/10 border-purple-500/20';
        iconColor = 'text-purple-400';
        glowShadow = 'shadow-[0_0_20px_rgba(168,85,247,0.15)]';
    }

    return (
        <div className={`group relative w-[440px] bg-gradient-to-br ${bgGradient} rounded-2xl border ${borderColor} p-4 backdrop-blur-xl text-center font-sans transition-all duration-300 ${glowShadow} ${selected ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-[#070c14] shadow-[0_0_30px_rgba(59,130,246,0.3)] z-30' : 'z-10'}`}>
            <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl pointer-events-none"></div>

            {/* Top Handles */}
            <Handle type="target" position={Position.Top} id="t-top" className="!bg-slate-400 !w-2 !h-2 !border-slate-800" style={{ left: '50%' }} />
            <Handle type="source" position={Position.Top} id="s-top" className="!bg-slate-400 !w-2 !h-2 !opacity-0" style={{ left: '50%' }} />

            {/* Left Handles */}
            <Handle type="target" position={Position.Left} id="t-left" className="!bg-slate-400 !w-2 !h-2 !border-slate-800" style={{ top: '50%' }} />
            <Handle type="source" position={Position.Left} id="s-left" className="!bg-slate-400 !w-2 !h-2 !opacity-0" style={{ top: '50%' }} />

            {/* Right Handles */}
            <Handle type="target" position={Position.Right} id="t-right" className="!bg-slate-400 !w-2 !h-2 !border-slate-800" style={{ top: '50%' }} />
            <Handle type="source" position={Position.Right} id="s-right" className="!bg-slate-400 !w-2 !h-2 !opacity-0" style={{ top: '50%' }} />

            {/* Header / Badges */}
            <div className="flex flex-wrap justify-between items-center gap-1.5 mb-3">
                <span className={`text-[9.5px] font-bold px-2.5 py-0.5 rounded-md border ${badgeColor} shadow-inner`}>
                    {data.vlan || 'LAN • VLAN 10'}
                </span>
                {data.rca?.isRootCause && (
                    <span className="text-[9.5px] text-rose-300 font-extrabold flex items-center gap-1 bg-rose-950/80 px-2 py-0.5 rounded-md border border-rose-500 animate-pulse shadow-[0_0_10px_rgba(244,63,94,0.4)]">
                        🔥 ROOT CAUSE ({data.rca.impactCount} DOWN)
                    </span>
                )}
                {data.rca?.classification === 'CASCADING_DOWN' && (
                    <span className="text-[9px] text-amber-300 font-semibold flex items-center gap-1 bg-amber-950/70 px-2 py-0.5 rounded-md border border-amber-600/60" title={`Terputus akibat parent switch down: ${data.rca.rootCauseDevice?.HOSTNAME || 'Uplink'}`}>
                        ⛓️ CASCADING
                    </span>
                )}
                {data.floor && (
                    <span className="text-[9.5px] text-slate-300 font-medium flex items-center gap-1 bg-slate-900/80 px-2.5 py-0.5 rounded-md border border-slate-700/50">
                        <MapPin className="w-3 h-3 text-blue-400" /> {data.floor}
                    </span>
                )}
            </div>

            {/* Icon Center */}
            <div className="flex justify-center my-3 relative">
                {isDown && (
                    <div className="absolute inset-0 bg-rose-500/20 blur-xl rounded-full"></div>
                )}
                <div className={`p-3 rounded-xl border ${iconBg} shadow-inner relative z-10 group-hover:scale-110 transition-transform duration-300`}>
                    <Network className={`w-6 h-6 ${iconColor}`} />
                </div>
            </div>

            {/* Title & Desc */}
            <div className="font-bold text-sm text-slate-100 tracking-wide break-words group-hover:text-blue-200 transition-colors px-2">
                {data.label}
            </div>

            {/* IP Address, MAC & Vendor Badge */}
            <div className="flex items-center justify-center gap-2 mt-1.5 flex-wrap">
                <span className="text-[11px] font-mono text-blue-400 font-bold bg-blue-950/40 px-2 py-0.5 rounded border border-blue-900/50">{data.ip}</span>
                {data.mac && data.mac !== '-' && (
                    <span className="text-[9px] font-mono text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                        {data.mac}
                    </span>
                )}
                {data.vendor && (
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/80">
                        {data.vendor}
                    </span>
                )}
            </div>

            {/* Location Box */}
            {data.location && (
                <div className="text-[10px] text-blue-300/90 font-medium bg-blue-950/30 border border-blue-900/40 rounded-lg px-2.5 py-1 mt-2 whitespace-normal shadow-inner">
                    {data.location}
                </div>
            )}

            {/* Quick System Info Badge (Firmware / Uptime) */}
            {(data.firmware || data.uptime) && (
                <div className="mt-2.5 px-2.5 py-1.5 bg-slate-950/70 border border-slate-800/80 rounded-lg text-left text-[9.5px] font-mono flex flex-col gap-0.5 shadow-inner">
                    {data.firmware && (
                        <div className="text-slate-400 truncate" title={data.firmware}>
                            <span className="text-slate-500 font-bold">FW: </span>
                            <span className="text-slate-300">{data.firmware}</span>
                        </div>
                    )}
                    {data.uptime && (
                        <div className="text-slate-400">
                            <span className="text-slate-500 font-bold">UPTIME: </span>
                            <span className="text-emerald-400 font-semibold">{data.uptime}</span>
                        </div>
                    )}
                </div>
            )}

            {/* Quick Metrics Bar (CPU / RAM / SUHU) */}
            <div className="mt-2.5 pt-2 border-t border-slate-800/80 grid grid-cols-3 gap-2 text-[9.5px] font-mono text-slate-300">
                <div className="bg-slate-950/60 p-1.5 rounded-lg border border-slate-800 text-center">
                    <span className="text-slate-500 block text-[8px] font-bold">CPU</span>
                    <span className={`font-bold ${data.cpu && data.cpu !== '-' && data.cpu !== 'N/A' && parseInt(data.cpu) > 80 ? 'text-rose-400' : 'text-slate-200'}`}>
                        {data.cpu && data.cpu !== 'N/A' ? (data.cpu.toString().includes('%') ? data.cpu : `${data.cpu}%`) : '-'}
                    </span>
                </div>
                <div className="bg-slate-950/60 p-1.5 rounded-lg border border-slate-800 text-center">
                    <span className="text-slate-500 block text-[8px] font-bold">RAM</span>
                    <span className={`font-bold ${data.memory && data.memory !== '-' && data.memory !== 'N/A' && parseInt(data.memory) > 85 ? 'text-rose-400' : 'text-slate-200'}`}>
                        {data.memory && data.memory !== 'N/A' ? (data.memory.toString().includes('%') ? data.memory : `${data.memory}%`) : '-'}
                    </span>
                </div>
                <div className="bg-slate-950/60 p-1.5 rounded-lg border border-slate-800 text-center">
                    <span className="text-slate-500 block text-[8px] font-bold">SUHU</span>
                    <span className={`font-bold ${data.temperature && parseInt(data.temperature) > 60 ? 'text-rose-400' : 'text-amber-400'}`}>
                        {data.temperature ? `${data.temperature}°C` : '-'}
                    </span>
                </div>
            </div>

            {/* Traffic Bandwidth Metrics Bar (IN / OUT) */}
            {(data.trafficIn || data.trafficOut || (data.networkTraffic && (data.networkTraffic.in || data.networkTraffic.out))) && (
                <div className="mt-2 grid grid-cols-2 gap-2 text-[9px] font-mono">
                    <div className="bg-slate-950/60 px-2.5 py-1.5 rounded-lg border border-slate-800/80 flex items-center justify-between">
                        <span className="text-emerald-500/80 font-bold">▼ IN:</span>
                        <span className="text-slate-300 font-semibold">{data.trafficIn || data.networkTraffic?.in || '0 MB'}</span>
                    </div>
                    <div className="bg-slate-950/60 px-2.5 py-1.5 rounded-lg border border-slate-800/80 flex items-center justify-between">
                        <span className="text-blue-400/80 font-bold">▲ OUT:</span>
                        <span className="text-slate-300 font-semibold">{data.trafficOut || data.networkTraffic?.out || '0 MB'}</span>
                    </div>
                </div>
            )}

            {/* Port Grid Dinamis (8, 16, 24, atau 48 Ports) */}
            {(() => {
                const totalPorts = parseInt(data.port, 10) || 48;
                const halfPorts = Math.ceil(totalPorts / 2);

                return (
                    <div className="mt-3 px-1">
                        <div className="flex justify-between items-center text-[9px] text-slate-400 font-bold mb-1.5 uppercase tracking-wider">
                            <span>Network Ports (1-{totalPorts})</span>
                            {data.ports && (
                                <span className="text-emerald-400 font-mono">
                                    {data.ports.filter(p => p.status === 'up').length}/{data.ports.length} UP
                                </span>
                            )}
                        </div>

                        {/* 2-Row Switch Port Matrix Zigzag Box */}
                        <div className="p-3 bg-slate-950/95 rounded-xl border border-slate-800/80 shadow-inner flex flex-col gap-y-3 overflow-hidden">
                            {/* Baris Atas: Port Ganjil (1, 3, 5, ... ) */}
                            <div 
                                className="grid gap-[3px] mr-2" 
                                style={{ gridTemplateColumns: `repeat(${halfPorts}, minmax(0, 1fr))` }}
                            >
                                {Array.from({ length: halfPorts }).map((_, col) => {
                                    const portNum = col * 2 + 1;
                                    let isUp = false;
                                    let portAlias = '';
                                    let portTrafficSummary = '';
                                    let portLoadColor = 'bg-slate-900 border-slate-700/70 hover:bg-slate-700';
                                    let portTextColor = 'text-slate-400';
                                    let portGlow = '';

                                    if (data.ports && Array.isArray(data.ports)) {
                                        const pData = data.ports.find(p => {
                                            if (!p) return false;
                                            const sName = String(p.shortName || '').toLowerCase().trim();
                                            const pName = String(p.name || '').toLowerCase().trim();
                                            
                                            // 1. Direct name / short name e.g. "1", "port1", "p1", "gi1"
                                            if (sName === String(portNum) || sName === `port${portNum}` || sName === `p${portNum}` || sName === `gi${portNum}` || sName === `fa${portNum}`) return true;

                                            // 2. Cisco Stack Pattern: Gi1/0/X (1-24) & Gi2/0/X (25-48)
                                            const stackMatch = pName.match(/(?:gi|fa|te|gigabitethernet|fastethernet)(\d+)\/(\d+)\/(\d+)/i);
                                            if (stackMatch) {
                                                const swNum = parseInt(stackMatch[1], 10);
                                                const ptNum = parseInt(stackMatch[3], 10);
                                                if (swNum === 1 && ptNum === portNum) return true;
                                                if (swNum === 2 && ptNum === (portNum - 24)) return true;
                                            }

                                            // 3. FortiGate & Generic Interface regex (e.g. port3, ethernet3, GigabitEthernet3)
                                            const genericMatch = pName.match(/(?:gi|fa|te|eth|ethernet|gigabitethernet|port|ge)[^\d]*(\d+)$/i);
                                            if (genericMatch && parseInt(genericMatch[1], 10) === portNum) return true;

                                            return false;
                                        });
                                        
                                        if (pData && (pData.status === 'up' || pData.status === 'UP' || pData.status === 1 || pData.status === '1')) {
                                            isUp = true;
                                            const inBps = pData.inBps || 0;
                                            const outBps = pData.outBps || 0;
                                            const speed = pData.speed || 1000000000; // default 1Gbps
                                            const maxUsage = Math.max(inBps, outBps);
                                            const usagePct = speed > 0 ? (maxUsage / speed) * 100 : 0;
                                            const hasErrors = (pData.inErrors > 0 || pData.outErrors > 0);

                                            if (hasErrors || usagePct >= 80) {
                                                // Beban Kritis / Overload / Packet Drops (Merah)
                                                portLoadColor = 'bg-rose-500 border-rose-400';
                                                portGlow = 'shadow-[0_0_8px_rgba(244,63,94,0.8)]';
                                                portTextColor = 'text-white font-black';
                                            } else if (usagePct >= 50) {
                                                // Beban Sedang (Kuning / Amber)
                                                portLoadColor = 'bg-amber-400 border-amber-300';
                                                portGlow = 'shadow-[0_0_8px_rgba(245,158,11,0.8)]';
                                                portTextColor = 'text-slate-950 font-black';
                                            } else {
                                                // Normal / Ringan (Hijau)
                                                portLoadColor = 'bg-emerald-500 border-emerald-400';
                                                portGlow = 'shadow-[0_0_8px_rgba(16,185,129,0.8)]';
                                                portTextColor = 'text-slate-950 font-black';
                                            }

                                            if (inBps > 0 || outBps > 0) {
                                                portTrafficSummary = ` | IN: ${(inBps / (1024 * 1024)).toFixed(1)}M OUT: ${(outBps / (1024 * 1024)).toFixed(1)}M`;
                                            }
                                        }
                                        if (pData?.alias) portAlias = ` [${pData.alias}]`;
                                    }

                                    return (
                                        <div
                                            key={`port-${portNum}`}
                                            className={`relative w-full aspect-square rounded-[3px] border transition-all group/port flex items-center justify-center ${isUp ? `${portLoadColor} ${portGlow} z-10` : portLoadColor}`}
                                            title={`Port ${portNum}${portAlias} ${isUp ? '(UP' + portTrafficSummary + ')' : '(DOWN)'}`}
                                        >
                                            <span className={`text-[7px] font-mono select-none pointer-events-none leading-none ${portTextColor}`}>
                                                {portNum}
                                            </span>
                                            {/* Handle target & source dari atas */}
                                            <Handle
                                                type="target"
                                                position={Position.Top}
                                                id={`p-top-${portNum}`}
                                                isConnectable={true}
                                                className="!w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none !bg-transparent group-hover/port:!bg-blue-400/20 z-10"
                                                style={{ position: 'absolute' }}
                                            />
                                            <Handle
                                                type="source"
                                                position={Position.Top}
                                                id={`s-p-top-${portNum}`}
                                                isConnectable={true}
                                                className="!w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none !bg-transparent group-hover/port:!bg-blue-400/40 cursor-crosshair z-20"
                                                style={{ position: 'absolute' }}
                                            />
                                            {/* Handle target & source dari bawah */}
                                            <Handle
                                                type="target"
                                                position={Position.Bottom}
                                                id={`p-${portNum}`}
                                                isConnectable={true}
                                                className="!w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none !bg-transparent group-hover/port:!bg-blue-400/20 z-10"
                                                style={{ position: 'absolute' }}
                                            />
                                            <Handle
                                                type="source"
                                                position={Position.Bottom}
                                                id={`s-p-${portNum}`}
                                                isConnectable={true}
                                                className="!w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none !bg-transparent group-hover/port:!bg-blue-400/40 cursor-crosshair z-20"
                                                style={{ position: 'absolute' }}
                                            />
                                        </div>
                                    );
                                })}
                            </div>

                            {/* Baris Bawah: Port Genap (2, 4, 6, ... ) */}
                            <div 
                                className="grid gap-[3px] ml-2" 
                                style={{ gridTemplateColumns: `repeat(${halfPorts}, minmax(0, 1fr))` }}
                            >
                                {Array.from({ length: halfPorts }).map((_, col) => {
                                    const portNum = (col + 1) * 2;
                            let isUp = false;
                            let portAlias = '';
                            let portTrafficSummary = '';
                            let portLoadColor = 'bg-slate-900 border-slate-700/70 hover:bg-slate-700';
                            let portTextColor = 'text-slate-400';
                            let portGlow = '';

                            if (data.ports && Array.isArray(data.ports)) {
                                const pData = data.ports.find(p => {
                                    if (!p) return false;
                                    const sName = String(p.shortName || '').toLowerCase().trim();
                                    const pName = String(p.name || '').toLowerCase().trim();
                                    
                                    // 1. Direct name / short name e.g. "2", "port2", "p2", "gi2"
                                    if (sName === String(portNum) || sName === `port${portNum}` || sName === `p${portNum}` || sName === `gi${portNum}` || sName === `fa${portNum}`) return true;

                                    // 2. Cisco Stack Pattern: Gi1/0/X (1-24) & Gi2/0/X (25-48)
                                    const stackMatch = pName.match(/(?:gi|fa|te|gigabitethernet|fastethernet)(\d+)\/(\d+)\/(\d+)/i);
                                    if (stackMatch) {
                                        const swNum = parseInt(stackMatch[1], 10);
                                        const ptNum = parseInt(stackMatch[3], 10);
                                        if (swNum === 1 && ptNum === portNum) return true;
                                        if (swNum === 2 && ptNum === (portNum - 24)) return true;
                                    }

                                    // 3. FortiGate & Generic Interface regex (e.g. port4, ethernet4, GigabitEthernet4)
                                    const genericMatch = pName.match(/(?:gi|fa|te|eth|ethernet|gigabitethernet|port|ge)[^\d]*(\d+)$/i);
                                    if (genericMatch && parseInt(genericMatch[1], 10) === portNum) return true;

                                    return false;
                                });
                                
                                if (pData && (pData.status === 'up' || pData.status === 'UP' || pData.status === 1 || pData.status === '1')) {
                                    isUp = true;
                                    const inBps = pData.inBps || 0;
                                    const outBps = pData.outBps || 0;
                                    const speed = pData.speed || 1000000000;
                                    const maxUsage = Math.max(inBps, outBps);
                                    const usagePct = speed > 0 ? (maxUsage / speed) * 100 : 0;
                                    const hasErrors = (pData.inErrors > 0 || pData.outErrors > 0);

                                    if (hasErrors || usagePct >= 80) {
                                        portLoadColor = 'bg-rose-500 border-rose-400';
                                        portGlow = 'shadow-[0_0_8px_rgba(244,63,94,0.8)]';
                                        portTextColor = 'text-white font-black';
                                    } else if (usagePct >= 50) {
                                        portLoadColor = 'bg-amber-400 border-amber-300';
                                        portGlow = 'shadow-[0_0_8px_rgba(245,158,11,0.8)]';
                                        portTextColor = 'text-slate-950 font-black';
                                    } else {
                                        portLoadColor = 'bg-emerald-500 border-emerald-400';
                                        portGlow = 'shadow-[0_0_8px_rgba(16,185,129,0.8)]';
                                        portTextColor = 'text-slate-950 font-black';
                                    }

                                    if (inBps > 0 || outBps > 0) {
                                        portTrafficSummary = ` | IN: ${(inBps / (1024 * 1024)).toFixed(1)}M OUT: ${(outBps / (1024 * 1024)).toFixed(1)}M`;
                                    }
                                }
                                if (pData?.alias) portAlias = ` [${pData.alias}]`;
                            }

                            return (
                                <div
                                    key={`port-${portNum}`}
                                    className={`relative w-full aspect-square rounded-[3px] border transition-all group/port flex items-center justify-center ${isUp ? `${portLoadColor} ${portGlow} z-10` : portLoadColor}`}
                                    title={`Port ${portNum}${portAlias} ${isUp ? '(UP' + portTrafficSummary + ')' : '(DOWN)'}`}
                                >
                                    <span className={`text-[7px] font-mono select-none pointer-events-none leading-none ${portTextColor}`}>
                                        {portNum}
                                    </span>
                                    {/* Handle target & source dari atas */}
                                    <Handle
                                        type="target"
                                        position={Position.Top}
                                        id={`p-top-${portNum}`}
                                        isConnectable={true}
                                        className="!w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none !bg-transparent group-hover/port:!bg-blue-400/20 z-10"
                                        style={{ position: 'absolute' }}
                                    />
                                    <Handle
                                        type="source"
                                        position={Position.Top}
                                        id={`s-p-top-${portNum}`}
                                        isConnectable={true}
                                        className="!w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none !bg-transparent group-hover/port:!bg-blue-400/40 cursor-crosshair z-20"
                                        style={{ position: 'absolute' }}
                                    />
                                    {/* Handle target & source dari bawah */}
                                    <Handle
                                        type="target"
                                        position={Position.Bottom}
                                        id={`p-${portNum}`}
                                        isConnectable={true}
                                        className="!w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none !bg-transparent group-hover/port:!bg-blue-400/20 z-10"
                                        style={{ position: 'absolute' }}
                                    />
                                    <Handle
                                        type="source"
                                        position={Position.Bottom}
                                        id={`s-p-${portNum}`}
                                        isConnectable={true}
                                        className="!w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none !bg-transparent group-hover/port:!bg-blue-400/40 cursor-crosshair z-20"
                                        style={{ position: 'absolute' }}
                                    />
                                </div>
                            );
                        })}
                            </div>
                        </div>
                    </div>
                );
            })()}

            {/* Footer Status & Model */}
            <div className="mt-3 pt-2.5 border-t border-slate-700/50 text-[9px] font-bold text-slate-400 flex items-center justify-between px-1">
                <div className="flex items-center gap-1.5 font-mono text-[9px] truncate max-w-[160px]">
                    {data.model && data.model !== 'N/A' ? (
                        <span className="text-slate-200 font-semibold truncate" title={data.model}>{data.model}</span>
                    ) : (
                        <span className="text-slate-500">{data.category?.toUpperCase() || 'SWITCH'}</span>
                    )}
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                    <span className="tracking-wider">{isDown ? 'OFFLINE' : isWarning ? 'WARNING' : 'ONLINE'}</span>
                    <span className={`relative flex w-2 h-2`}>
                        {isDown && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>}
                        <span className={`relative inline-flex rounded-full w-2 h-2 ${isDown ? 'bg-rose-500' : isWarning ? 'bg-amber-500' : 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]'}`}></span>
                    </span>
                </div>
            </div>

            {/* Bottom Card Center Handles */}
            <Handle type="target" position={Position.Bottom} id="t-bottom" className="!bg-slate-400 !w-2 !h-2 !border-slate-800" style={{ left: '50%' }} />
            <Handle type="source" position={Position.Bottom} id="s-bottom" className="!bg-slate-400 !w-2 !h-2 !opacity-0" style={{ left: '50%' }} />
        </div>
    );
}

export default memo(CustomDeviceNode);