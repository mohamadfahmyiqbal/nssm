import React, { useState } from 'react';
import { X, Network, Loader2, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';

export default function AddDeviceModal({ isOpen, onClose, onSave }) {
    const [step, setStep] = useState('form'); // 'form' | 'testing' | 'result'
    const [formData, setFormData] = useState({
        hostname: 'SW-ACCESS-FLOOR3',
        ip: '192.168.10.30',
        vendor: 'Cisco Switch',
        snmpVersion: 'v2c',
        communityKey: 'public',
        autoDiscover: true,
    });

    if (!isOpen) return null;

    const handleTestSNMP = () => {
        setStep('testing');
        setTimeout(() => {
            setStep('result');
        }, 2000);
    };

    const handleResetAndClose = () => {
        setStep('form');
        onClose();
    };

    return (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden font-sans text-xs text-slate-200">

                {/* Modal Header */}
                <div className="flex justify-between items-center px-5 py-3.5 bg-slate-800/80 border-b border-slate-700">
                    <h3 className="font-bold text-sm tracking-wide text-slate-100 uppercase">
                        TAMBAH PERANGKAT BARU & AUTO-DISCOVER
                    </h3>
                    <button onClick={handleResetAndClose} className="p-1 text-slate-400 hover:text-slate-100 hover:bg-slate-700 rounded-lg">
                        <X className="w-4 h-4" />
                    </button>
                </div>

                {/* Modal Content */}
                <div className="p-5 space-y-4">

                    {/* Form State */}
                    {step === 'form' && (
                        <>
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                                        Hostname / Device Name Management <span className="text-rose-500">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        value={formData.hostname}
                                        onChange={(e) => setFormData({ ...formData, hostname: e.target.value })}
                                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
                                    />
                                </div>
                                <div>
                                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                                        IP Address Management <span className="text-rose-500">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        value={formData.ip}
                                        onChange={(e) => setFormData({ ...formData, ip: e.target.value })}
                                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
                                    />
                                </div>
                            </div>

                            {/* Vendor Selection */}
                            <div>
                                <label className="block text-[11px] font-semibold text-slate-400 mb-2">
                                    Vendor / Type <span className="text-rose-500">*</span>
                                </label>
                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                    {['Cisco Switch', 'HPE Switch', 'UPS System', 'Panasonic NVR'].map((vendor) => (
                                        <label
                                            key={vendor}
                                            className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors ${formData.vendor === vendor
                                                    ? 'bg-blue-600/20 border-blue-500 text-blue-400 font-bold'
                                                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                                                }`}
                                        >
                                            <input
                                                type="radio"
                                                name="vendor"
                                                checked={formData.vendor === vendor}
                                                onChange={() => setFormData({ ...formData, vendor })}
                                                className="hidden"
                                            />
                                            <span>{vendor}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* SNMP Credentials */}
                            <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-800/80 space-y-3">
                                <span className="font-bold text-slate-300 text-[11px]">SNMP Version & Community Key</span>
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="block text-slate-400 text-[10px] mb-1">SNMP Version</label>
                                        <select
                                            value={formData.snmpVersion}
                                            onChange={(e) => setFormData({ ...formData, snmpVersion: e.target.value })}
                                            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-200 font-mono"
                                        >
                                            <option value="v2c">v2c</option>
                                            <option value="v3">v3</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-slate-400 text-[10px] mb-1">Community Key</label>
                                        <input
                                            type="text"
                                            value={formData.communityKey}
                                            onChange={(e) => setFormData({ ...formData, communityKey: e.target.value })}
                                            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-200 font-mono"
                                        />
                                    </div>
                                </div>
                            </div>

                            {/* Discovery Option Checkbox */}
                            <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-300">
                                <input
                                    type="checkbox"
                                    checked={formData.autoDiscover}
                                    onChange={(e) => setFormData({ ...formData, autoDiscover: e.target.checked })}
                                    className="rounded border-slate-700 bg-slate-950 text-blue-600 focus:ring-0"
                                />
                                <span>Auto-Discover Link Topology (LLDP/CDP Table)</span>
                            </label>

                            {/* Action Button */}
                            <button
                                onClick={handleTestSNMP}
                                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 transition-colors"
                            >
                                <span>✓ Test SNMP & Discover</span>
                            </button>
                        </>
                    )}

                    {/* Testing SNMP Loading State */}
                    {step === 'testing' && (
                        <div className="py-12 flex flex-col items-center justify-center gap-4 text-center">
                            <div className="relative">
                                <div className="w-16 h-16 rounded-full border-4 border-blue-500/20 border-t-blue-500 animate-spin" />
                                <Network className="w-6 h-6 text-blue-400 absolute inset-0 m-auto" />
                            </div>
                            <div>
                                <p className="font-bold text-slate-100 text-sm">Menguji Koneksi SNMP & Scanning LLDP...</p>
                                <p className="text-slate-400 text-xs mt-1 font-mono">Connecting to {formData.ip}:161</p>
                            </div>
                        </div>
                    )}

                    {/* Result State */}
                    {step === 'result' && (
                        <div className="space-y-4">
                            <div className="bg-emerald-950/40 border border-emerald-500/40 p-3 rounded-xl font-mono space-y-1 text-emerald-400">
                                <div className="flex items-center gap-2 font-bold">
                                    <CheckCircle2 className="w-4 h-4" />
                                    <span>Status: Koneksi SNMP Sukses</span>
                                </div>
                                <div className="pl-6 text-[11px] text-slate-300 space-y-0.5">
                                    <p>• Vendor: Cisco Systems</p>
                                    <p>• Model: Catalyst 2960X</p>
                                    <p>• SysObjectID: .1.3.6.1.4.1.9.1.1856</p>
                                </div>
                            </div>

                            <div className="bg-amber-950/40 border border-amber-500/40 p-3 rounded-xl font-mono text-amber-300 text-[11px] space-y-1">
                                <div className="flex items-center gap-2 font-bold">
                                    <AlertTriangle className="w-4 h-4" />
                                    <span>Neighbors Ditemukan: 3 Switch Tetangga Terdeteksi</span>
                                </div>
                                <p className="pl-6 text-slate-300">Link 1: Fa0/24 &lt;--&gt; SW-CORE-CISCO-01 (Gi0/1)</p>
                                <p className="pl-6 text-slate-300">Link 2: Fa0/23 &lt;--&gt; SW-CORE-CISCO-02 (Gi0/1)</p>
                            </div>

                            <div className="flex gap-2 pt-2">
                                <button
                                    onClick={handleResetAndClose}
                                    className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold"
                                >
                                    Batal
                                </button>
                                <button
                                    onClick={() => {
                                        onSave(formData);
                                        handleResetAndClose();
                                    }}
                                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center justify-center gap-2"
                                >
                                    <span>SIMPAN & INTEGRASIKAN</span>
                                    <ArrowRight className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    )}

                </div>
            </div>
        </div>
    );
}