import React, { useState, useEffect, useRef } from 'react';
import ReactFlow, { Background, Controls, MiniMap, addEdge } from 'reactflow';
import { nodeTypes } from '../nodes/nodeTypes';
import LiveAlertLog from '../dashboard/LiveAlertLog';
import TopologyLegend from './TopologyLegend';
import TopologyHeader from './TopologyHeader';
import DeviceDetailPanel from './DeviceDetailPanel';
import { useDevices } from '../../context/DeviceContext';
import { SelectionMode } from 'reactflow';
import { showConfirm, showToast } from '../../utils/swal';

import { useTopologySnmp } from './hooks/useTopologySnmp';
import { useTopologyNodes } from './hooks/useTopologyNodes';
import { useTopologyLayout } from './hooks/useTopologyLayout';

export default function TopologyCanvas({ activeFilter }) {
    const { devices } = useDevices();
    const [selectedDevice, setSelectedDevice] = useState(null);
    const [rfInstance, setRfInstance] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [connectionType, setConnectionType] = useState('UTP');
    const [isSelectMode, setIsSelectMode] = useState(false);
    
    const crosshairHRef = useRef(null);
    const crosshairVRef = useRef(null);
    const layoutApplied = useRef(false);

    // Layout Hook (API Settings)
    const {
        savedLayoutConfig,
        pollingOverrides,
        notificationPrefs,
        handleSaveLayout: saveLayoutConfig,
        handleResetLayout: resetLayoutConfig,
        handlePollingOverrideChange,
        handleNotificationToggle
    } = useTopologyLayout(
        // we will pass nodes/edges from nodes hook inside the wrappers below
        [], () => {}, [], () => {}, [], rfInstance
    );

    // Nodes & Edges Hook
    const {
        nodes, setNodes,
        edges, setEdges,
        defaultEdges,
        handleGroup, handleUngroup,
        onNodesChange, onEdgesChange
    } = useTopologyNodes(
        devices, activeFilter, null, selectedDevice, savedLayoutConfig, layoutApplied, rfInstance
    );

    // SNMP Polling Hook
    const { snmpData, nvrSnmpData, isLoadingSnmp, isLoadingNvrSnmp } = useTopologySnmp(selectedDevice, setNodes);

    // Rebind Layout Wrappers with current nodes/edges
    const {
        handleSaveLayout,
        handleResetLayout
    } = useTopologyLayout(nodes, setNodes, edges, setEdges, defaultEdges, rfInstance);

    // Mouse / Keyboard Handlers
    const handleMouseMove = (e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        if (crosshairHRef.current) {
            crosshairHRef.current.style.transform = `translateY(${y}px)`;
            crosshairHRef.current.style.opacity = '1';
        }
        if (crosshairVRef.current) {
            crosshairVRef.current.style.transform = `translateX(${x}px)`;
            crosshairVRef.current.style.opacity = '1';
        }
    };

    const handleMouseLeave = () => {
        if (crosshairHRef.current) crosshairHRef.current.style.opacity = '0';
        if (crosshairVRef.current) crosshairVRef.current.style.opacity = '0';
    };

    useEffect(() => {
        const handleKeyDown = (e) => {
            if (e.key === 'Shift' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
                setIsSelectMode(true);
            }
        };
        const handleKeyUp = (e) => {
            if (e.key === 'Shift') setIsSelectMode(false);
        };
        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, []);

    const handleSearchChange = (e) => {
        const query = e.target.value;
        setSearchQuery(query);
        if (query.trim().length > 1) {
            const results = nodes.filter(n => n.data.label?.toLowerCase().includes(query.toLowerCase()) || n.data.ip?.includes(query));
            setSearchResults(results);
        } else {
            setSearchResults([]);
        }
    };

    const handleSelectSearchResult = (node) => {
        setSearchQuery('');
        setSearchResults([]);
        setSelectedDevice(node.data);
        if (rfInstance) {
            rfInstance.setCenter(node.position.x, node.position.y, { zoom: 1.2, duration: 800 });
        }
    };

    const onConnect = (connection) => {
        let strokeColor = '#3b82f6';
        let strokeDasharray = 'none';
        if (connectionType === 'FO') strokeColor = '#ef4444';
        else if (connectionType === 'Wireless') { strokeColor = '#a855f7'; strokeDasharray = '5,5'; }

        setEdges((eds) => addEdge({
            ...connection,
            id: `e-${connection.source}-${connection.target}-${Date.now()}`,
            animated: true,
            type: 'smoothstep',
            style: { stroke: strokeColor, strokeWidth: 2, strokeDasharray }
        }, eds));
    };

    const onEdgeClick = (event, edge) => {
        showConfirm('Putus Koneksi?', 'Apakah Anda yakin ingin memutus koneksi antara perangkat ini?', 'Ya, Putuskan')
        .then((result) => {
            if (result.isConfirmed) {
                setEdges((eds) => eds.filter((e) => e.id !== edge.id));
                showToast('info', 'Koneksi berhasil diputus. Jangan lupa Simpan Layout.');
            }
        });
    };

    const notifKey = selectedDevice ? (selectedDevice.label || selectedDevice.hostname || selectedDevice.name || selectedDevice.id) : null;

    return (
        <div style={{ width: '100%', height: 'calc(100vh - 120px)', position: 'relative' }} className="flex flex-col gap-3">
            <TopologyHeader
                searchQuery={searchQuery}
                handleSearchChange={handleSearchChange}
                searchResults={searchResults}
                handleSelectSearchResult={handleSelectSearchResult}
                handleGroup={handleGroup}
                handleUngroup={handleUngroup}
                isSelectMode={isSelectMode}
                setIsSelectMode={setIsSelectMode}
                connectionType={connectionType}
                setConnectionType={setConnectionType}
                handleResetLayout={handleResetLayout}
                handleSaveLayout={handleSaveLayout}
            />

            <div 
                className="flex-1 relative w-full rounded-xl overflow-hidden border border-slate-800/80 cursor-crosshair"
                onMouseMoveCapture={handleMouseMove}
                onMouseLeave={handleMouseLeave}
            >
                {/* Crosshair Horizontal */}
                <div 
                    ref={crosshairHRef}
                    className="pointer-events-none absolute left-0 right-0 top-0 h-[1px] bg-cyan-400 shadow-[0_0_8px_#22d3ee] z-[9999] transition-none"
                    style={{ opacity: 0 }}
                />
                {/* Crosshair Vertical */}
                <div 
                    ref={crosshairVRef}
                    className="pointer-events-none absolute top-0 bottom-0 left-0 w-[1px] bg-cyan-400 shadow-[0_0_8px_#22d3ee] z-[9999] transition-none"
                    style={{ opacity: 0 }}
                />

                <ReactFlow
                    nodes={nodes}
                    edges={edges}
                    nodeTypes={nodeTypes}
                    onNodesChange={onNodesChange}
                    onEdgesChange={onEdgesChange}
                    onConnect={onConnect}
                    onNodeClick={(e, node) => setSelectedDevice(node.data)}
                    onEdgeClick={onEdgeClick}
                    onInit={setRfInstance}
                    fitView
                    panOnDrag={!isSelectMode}
                    selectionOnDrag={isSelectMode}
                    selectionMode={SelectionMode.Partial}
                    multiSelectionKeyCode="Shift"
                    defaultEdgeOptions={{ type: 'smoothstep' }}
                    snapToGrid={true}
                    snapGrid={[24, 24]}
                    className="bg-[#070c14]"
                >
                    <Background variant="lines" color="#334155" gap={24} lineWidth={1} className="opacity-40" />
                    <Controls showInteractive={false} className="!bg-slate-900 !border-slate-800 !text-slate-200 fill-slate-200" />
                    <MiniMap nodeColor="#1e293b" maskColor="rgba(7, 12, 20, 0.7)" className="!bg-slate-950 !border-slate-800" />
                </ReactFlow>

                <DeviceDetailPanel
                    selectedDevice={selectedDevice}
                    setSelectedDevice={setSelectedDevice}
                    snmpData={snmpData}
                    isLoadingSnmp={isLoadingSnmp}
                    nvrSnmpData={nvrSnmpData}
                    isLoadingNvrSnmp={isLoadingNvrSnmp}
                    pollingOverrides={pollingOverrides}
                    handlePollingOverrideChange={handlePollingOverrideChange}
                    notificationPrefs={notificationPrefs}
                    handleNotificationToggle={handleNotificationToggle}
                    notifKey={notifKey}
                />

                <LiveAlertLog />
                <TopologyLegend />
            </div>
        </div>
    );
}