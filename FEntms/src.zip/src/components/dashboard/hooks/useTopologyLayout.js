import { useState, useEffect } from 'react';
import api from '../../../services/api';
import { showToast, showAlert, showConfirm } from '../../../utils/swal';
import dagre from 'dagre';

export const useTopologyLayout = (nodes, setNodes, edges, setEdges, defaultEdges, rfInstance) => {
    const [savedLayoutConfig, setSavedLayoutConfig] = useState(null);
    const [pollingOverrides, setPollingOverrides] = useState({});
    const [notificationPrefs, setNotificationPrefs] = useState({});

    useEffect(() => {
        const fetchLayoutConfig = async () => {
            try {
                const [resNodes, resEdges, resPolling, resNotification] = await Promise.all([
                    api.get('/settings/topology_layout').catch(() => ({ data: { data: { value: {} } } })),
                    api.get('/settings/topology_edges').catch(() => ({ data: { data: { value: null } } })),
                    api.get('/settings/polling_methods').catch(() => ({ data: { data: { value: {} } } })),
                    api.get('/settings/notification_preferences').catch(() => ({ data: { data: { value: {} } } }))
                ]);
                setSavedLayoutConfig({
                    nodes: resNodes.data?.data?.value || {},
                    edges: resEdges.data?.data?.value || null
                });
                setPollingOverrides(resPolling.data?.data?.value || {});
                setNotificationPrefs(resNotification.data?.data?.value || {});
            } catch (err) {
                console.error('Failed to load topology layout config:', err.message);
                setSavedLayoutConfig({ nodes: {}, edges: null });
            }
        };
        fetchLayoutConfig();
    }, []);

    const handleSaveLayout = async () => {
        try {
            const layoutToSave = {};
            nodes.forEach((n) => {
                const saveData = { ...n.position };
                if (n.parentNode) saveData.parentNode = n.parentNode;
                if (n.type === 'customGroup') {
                    saveData.isGroup = true;
                    saveData.width = n.style?.width;
                    saveData.height = n.style?.height;
                }
                layoutToSave[n.id] = saveData;
            });

            await Promise.all([
                api.post('/settings', {
                    key: 'topology_layout',
                    value: layoutToSave
                }),
                api.post('/settings', {
                    key: 'topology_edges',
                    value: edges
                })
            ]);

            showToast('success', 'Layout dan Garis Koneksi berhasil disimpan ke Database!');
        } catch (err) {
            console.error('Failed to save layout:', err);
            showAlert('Gagal', 'Terjadi kesalahan saat menyimpan layout ke database.', 'error');
        }
    };

    const handleResetLayout = () => {
        showConfirm('Reset Layout?', 'Semua koneksi manual akan diputus. Perangkat akan disusun ulang ke dalam Tree dan Grid otomatis, dan semua Group akan dihapus.', 'Ya, Reset Layout').then((result) => {
            if (result.isConfirmed) {
                setEdges(defaultEdges);

                setNodes((prevNodes) => {
                    const dagreGraph = new dagre.graphlib.Graph();
                    dagreGraph.setDefaultEdgeLabel(() => ({}));
                    dagreGraph.setGraph({ rankdir: 'TB', nodesep: 150, ranksep: 200, align: 'DL' });

                    const connectedNodeIds = new Set();
                    defaultEdges.forEach(e => {
                        connectedNodeIds.add(e.source);
                        connectedNodeIds.add(e.target);
                    });

                    const disconnectedEndpoints = [];

                    prevNodes.forEach((node) => {
                        if (node.type === 'customGroup') return; 

                        if (connectedNodeIds.has(node.id) || node.type === 'customDevice') {
                            const nodeWidth = node.type === 'customDevice' ? 240 : 180;
                            const nodeHeight = node.type === 'customDevice' ? 140 : 60;
                            dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
                        } else {
                            disconnectedEndpoints.push(node);
                        }
                    });

                    defaultEdges.forEach((edge) => {
                        dagreGraph.setEdge(edge.source, edge.target);
                    });

                    dagre.layout(dagreGraph);

                    let maxY = 0;
                    const newNodes = prevNodes
                        .filter(node => node.type !== 'customGroup') 
                        .map((node) => {
                            const { parentNode, extent, ...restNode } = node;
                            if (dagreGraph.hasNode(node.id)) {
                                const nodeWithPosition = dagreGraph.node(node.id);
                                const x = nodeWithPosition.x - nodeWithPosition.width / 2;
                                const y = nodeWithPosition.y - nodeWithPosition.height / 2;
                                if (y > maxY) maxY = y;
                                return { ...restNode, position: { x, y } };
                            }
                            return { ...restNode };
                        });

                    const gridCols = 8;
                    const gridSpacingX = 180;
                    const gridSpacingY = 100;
                    const gridStartY = maxY + 300;

                    const totalGridWidth = Math.min(disconnectedEndpoints.length, gridCols) * gridSpacingX;
                    const gridStartX = -(totalGridWidth / 2) + (gridSpacingX / 2);

                    disconnectedEndpoints.sort((a, b) => (a.data?.label || '').localeCompare(b.data?.label || ''));

                    disconnectedEndpoints.forEach((node, index) => {
                        const row = Math.floor(index / gridCols);
                        const col = index % gridCols;
                        const targetNodeIndex = newNodes.findIndex(n => n.id === node.id);
                        if (targetNodeIndex !== -1) {
                            newNodes[targetNodeIndex] = {
                                ...newNodes[targetNodeIndex],
                                position: {
                                    x: gridStartX + (col * gridSpacingX),
                                    y: gridStartY + (row * gridSpacingY)
                                }
                            };
                        }
                    });

                    return newNodes;
                });

                setTimeout(() => {
                    if (rfInstance) rfInstance.fitView({ padding: 0.2, duration: 800 });
                }, 100);
            }
        });
    };

    const handlePollingOverrideChange = async (ip, pid, method) => {
        const keyToUse = ip || pid;
        if (!keyToUse) return;

        const updatedOverrides = { ...pollingOverrides };
        if (method === 'auto') {
            delete updatedOverrides[keyToUse];
        } else {
            updatedOverrides[keyToUse] = method;
        }

        setPollingOverrides(updatedOverrides);

        try {
            await api.post('/settings', {
                key: 'polling_methods',
                value: updatedOverrides
            });
            showToast('success', 'Metode polling berhasil diperbarui!');
        } catch (err) {
            console.error('Failed to update polling method:', err);
            showToast('error', 'Gagal memperbarui metode polling');
        }
    };

    const handleNotificationToggle = async (pid) => {
        if (!pid) return;
        try {
            setNotificationPrefs(prev => {
                const currentPref = prev[pid] !== false;
                const newPrefs = { ...prev, [pid]: !currentPref };
                
                api.post('/settings', {
                    key: 'notification_preferences',
                    value: newPrefs
                }).then(() => {
                    showToast('success', 'Pengaturan notifikasi disimpan');
                }).catch(err => {
                    console.error('Failed to update notification preferences', err);
                    showToast('error', 'Gagal menyimpan pengaturan notifikasi');
                });
                
                return newPrefs;
            });
        } catch (error) {
            console.error('Error in handleNotificationToggle', error);
        }
    };

    return {
        savedLayoutConfig,
        pollingOverrides,
        notificationPrefs,
        handleSaveLayout,
        handleResetLayout,
        handlePollingOverrideChange,
        handleNotificationToggle
    };
};
