import { useState, useEffect } from 'react';
import api from '../../../services/api';

export const useTopologySnmp = (selectedDevice, setNodes) => {
    const [snmpData, setSnmpData] = useState(null);
    const [nvrSnmpData, setNvrSnmpData] = useState(null);
    const [isLoadingSnmp, setIsLoadingSnmp] = useState(false);
    const [isLoadingNvrSnmp, setIsLoadingNvrSnmp] = useState(false);

    useEffect(() => {
        const isSwitch = selectedDevice?.subType === 'switch' || selectedDevice?.label?.toLowerCase().includes('sw');
        const isSnmpTarget = selectedDevice && (selectedDevice.subType === 'nvr' || selectedDevice.subType === 'server' || selectedDevice.subType === 'camera' || selectedDevice.subType === 'cctv' || isSwitch);

        if (isSnmpTarget) {
            const ip = selectedDevice.ip || '127.0.0.1';
            setIsLoadingSnmp(true);
            setSnmpData(null);

            api.get(`/devices/${ip}/snmp`)
                .then(res => {
                    if (res.data.success) {
                        setSnmpData(res.data.data);
                        
                        // Suntikkan data ports ke dalam node di kanvas agar CustomDeviceNode bisa membacanya
                        if (res.data.data.ports) {
                            setNodes(nds => nds.map(n => {
                                if (n.id === selectedDevice.id) {
                                    return { ...n, data: { ...n.data, ports: res.data.data.ports } };
                                }
                                return n;
                            }));
                        }
                    }
                })
                .catch(err => {
                    console.error("Failed to fetch SNMP data:", err.message);
                })
                .finally(() => {
                    setIsLoadingSnmp(false);
                });

            // Fetch NVR specific data if applicable
            if (selectedDevice.subType === 'nvr' || selectedDevice.label?.toLowerCase().includes('nvr')) {
                setIsLoadingNvrSnmp(true);
                setNvrSnmpData(null);
                api.get(`/devices/${ip}/nvr-snmp`)
                    .then(res => {
                        if (res.data.success) {
                            setNvrSnmpData(res.data.data);
                        }
                    })
                    .catch(err => console.error("Failed to fetch NVR SNMP data:", err.message))
                    .finally(() => setIsLoadingNvrSnmp(false));
            } else {
                setNvrSnmpData(null);
            }
        } else {
            setSnmpData(null);
            setNvrSnmpData(null);
        }
    }, [selectedDevice, setNodes]);

    return {
        snmpData,
        nvrSnmpData,
        isLoadingSnmp,
        isLoadingNvrSnmp
    };
};
