import { useMemo, useState, useEffect, useRef } from 'react';
import { initialEdges } from '../../../data/topologyData';
import { showToast } from '../../../utils/swal';
import dagre from 'dagre';
import { applyNodeChanges, applyEdgeChanges } from 'reactflow';

export const useTopologyNodes = (devices, activeFilter, nvrSnmpData, selectedDevice, savedLayoutConfig, layoutApplied, rfInstance) => {
    const [nodes, setNodes] = useState([]);
    const [edges, setEdges] = useState([]);

    const enrichedNodes = useMemo(() => {
        const mappedNodes = [];

        devices.forEach((dev, idx) => {
            const devName = dev.hostname || dev.name;
            const devId = dev.PID || dev.id || `dev-db-${idx}`;

            const isSwitch = dev.type?.toLowerCase() === 'switch' || (devName && (devName.toLowerCase().includes('sw-') || devName.toLowerCase().includes('switch')));

            let calcSubType = dev.type?.toLowerCase();
            if (!calcSubType || calcSubType === 'server' || calcSubType === 'cctv') {
                if (devName && devName.toLowerCase().includes('nvr')) calcSubType = 'nvr';
                else if (devName && devName.toLowerCase().includes('cam')) calcSubType = 'camera';
                else calcSubType = calcSubType || 'server';
            }

            const isCctv = calcSubType === 'camera' || calcSubType === 'nvr' || (dev.vendor?.toLowerCase().includes('cctv'));

            mappedNodes.push({
                id: devId,
                type: isSwitch ? 'customDevice' : 'endpointDevice',
                data: {
                    id: devId,
                    label: devName || devId,
                    subType: calcSubType,
                    status: dev.status ? dev.status.toLowerCase() : 'up',
                    ip: dev.ip || dev.IP || '192.168.1.1',
                    category: isCctv ? 'cctv' : 'lan',
                    location: dev.location || 'DB Live Device',
                    floor: dev.floor || 'Unmapped',
                    layer: isSwitch ? 'ACCESS' : undefined,
                    cpu: 'N/A', // fallback
                    vlan: isCctv ? 'CCTV' : 'LAN', // fallback
                    manufacturer: (selectedDevice?.id === devId && nvrSnmpData) ? nvrSnmpData.info?.manufacturer : (dev.info?.manufacturer || dev.manufacturer),
                    model: (selectedDevice?.id === devId && nvrSnmpData) ? nvrSnmpData.info?.model : (dev.info?.model || dev.model),
                    alarmSummary: (selectedDevice?.id === devId && nvrSnmpData) ? nvrSnmpData.info?.alarmSummary : (dev.info?.alarmSummary || dev.alarmSummary),
                    temperature: (selectedDevice?.id === devId && nvrSnmpData) ? nvrSnmpData.info?.temperature : (dev.info?.temperature || dev.temperature),
                    port: dev.PORT || dev.port || '-'
                },
                position: {
                    x: 60 + (idx % 7) * 160,
                    y: 680 + Math.floor(idx / 7) * 110,
                },
            });
        });

        return mappedNodes;
    }, [devices, selectedDevice, nvrSnmpData]);

    const filteredNodes = useMemo(() => {
        if (activeFilter === 'LAN') {
            return enrichedNodes.filter(
                (node) => !node.data.vlan?.includes('CCTV') && node.data.category !== 'cctv'
            );
        }
        if (activeFilter === 'CCTV') {
            return enrichedNodes.filter(
                (node) => node.data.vlan?.includes('CCTV') || node.data.category === 'cctv' || node.id.includes('core')
            );
        }
        return enrichedNodes;
    }, [activeFilter, enrichedNodes]);

    const defaultEdges = useMemo(() => {
        const activeNodeIds = new Set(filteredNodes.map((n) => n.id));
        const edges = initialEdges.filter(
            (edge) => activeNodeIds.has(edge.source) && activeNodeIds.has(edge.target)
        );

        return edges;
    }, [filteredNodes]);

    // 2. Sinkronisasi nodes & edges ke state tanpa memanggil ulang API
    useEffect(() => {
        if (!savedLayoutConfig) return; // Tunggu layout dari API sebelum render nodes
        
        setNodes((prevNodes) => {
            const posMap = new Map(prevNodes.map((n) => [n.id, n.position]));
            const selectedMap = new Map(prevNodes.map((n) => [n.id, n.selected]));
            const savedLayout = savedLayoutConfig ? savedLayoutConfig.nodes : {};

            const isFirstDbApply = savedLayoutConfig && !layoutApplied.current;

            const newNodes = filteredNodes.map((node) => {
                const dbData = savedLayout[node.id];

                let dbPos = null;
                let dbParentNode = undefined;
                if (dbData && typeof dbData === 'object' && dbData.x !== undefined) {
                    dbPos = { x: dbData.x, y: dbData.y };
                    if (dbData.parentNode) dbParentNode = dbData.parentNode;
                }

                const prevNode = prevNodes.find(n => n.id === node.id);
                const currentPos = prevNode ? prevNode.position : null;

                let finalPos;
                let finalParent;

                if (isFirstDbApply && dbPos) {
                    finalPos = dbPos;
                    finalParent = dbParentNode;
                } else {
                    finalPos = currentPos || dbPos || node.position;
                    finalParent = prevNode ? prevNode.parentNode : dbParentNode;
                }

                const extent = finalParent ? 'parent' : undefined;

                const newNode = {
                    ...node,
                    position: finalPos,
                    selected: selectedMap.get(node.id) || false,
                };

                if (finalParent) {
                    newNode.parentNode = finalParent;
                    newNode.extent = extent;
                }

                return newNode;
            });

            const groupNodes = [];
            const prevGroupNodes = prevNodes.filter(n => n.type === 'customGroup');

            prevGroupNodes.forEach(gn => {
                groupNodes.push({ ...gn, selected: selectedMap.get(gn.id) || false });
            });

            if (isFirstDbApply) {
                const dbLayout = savedLayoutConfig.nodes;
                if (dbLayout) {
                    Object.keys(dbLayout).forEach(key => {
                        const data = dbLayout[key];
                        if (data && data.isGroup && !groupNodes.some(g => g.id === key)) {
                            groupNodes.push({
                                id: key,
                                type: 'customGroup',
                                position: { x: data.x, y: data.y },
                                style: { width: data.width, height: data.height },
                                data: { label: 'Group' },
                                selected: false,
                            });
                        }
                    });
                }
                layoutApplied.current = true;
            }

            let finalNodes = [...groupNodes, ...newNodes];

            // Safety check to ensure no node points to a missing parent
            const validParentIds = new Set(finalNodes.filter(n => n.type === 'customGroup').map(n => n.id));
            finalNodes = finalNodes.map(n => {
                if (n.parentNode && !validParentIds.has(n.parentNode)) {
                    const { parentNode, extent, ...rest } = n;
                    return rest;
                }
                return n;
            });

            return finalNodes;
        });

        setEdges((prevEdges) => {
            if (prevEdges.length > 0) {
                const activeNodeIds = new Set(filteredNodes.map((n) => n.id));
                const validEdges = prevEdges.filter((e) => activeNodeIds.has(e.source) && activeNodeIds.has(e.target));

                const existingEdgeIds = new Set(validEdges.map((e) => e.id));
                const newAutoEdges = defaultEdges.filter((e) =>
                    !existingEdgeIds.has(e.id) && activeNodeIds.has(e.source) && activeNodeIds.has(e.target)
                );

                return [...validEdges, ...newAutoEdges];
            } else {
                const savedEdges = savedLayoutConfig ? savedLayoutConfig.edges : null;
                if (savedEdges && Array.isArray(savedEdges)) {
                    const savedEdgeIds = new Set(savedEdges.map((e) => e.id));
                    const newEdges = defaultEdges.filter((e) => !savedEdgeIds.has(e.id));
                    return [...savedEdges, ...newEdges];
                }
                return defaultEdges;
            }
        });

        // Pastikan view terpusat setelah layout diterapkan pertama kali
        if (savedLayoutConfig && !layoutApplied.current && rfInstance) {
            setTimeout(() => {
                rfInstance.fitView({ padding: 0.2, duration: 800 });
            }, 300);
        }
    }, [filteredNodes, defaultEdges, savedLayoutConfig, rfInstance]);

    const handleGroup = () => {
        const selectedNodes = nodes.filter(n => n.selected && n.type !== 'customGroup');
        if (selectedNodes.length < 2) {
            showToast('warning', 'Pilih minimal 2 perangkat untuk di-group');
            return;
        }

        const padding = 60;
        let minX = Infinity;
        let minY = Infinity;
        let maxX = -Infinity;
        let maxY = -Infinity;

        selectedNodes.forEach(n => {
            const absoluteX = n.parentNode ? n.position.x + (nodes.find(p => p.id === n.parentNode)?.position.x || 0) : n.position.x;
            const absoluteY = n.parentNode ? n.position.y + (nodes.find(p => p.id === n.parentNode)?.position.y || 0) : n.position.y;
            if (absoluteX < minX) minX = absoluteX;
            if (absoluteY < minY) minY = absoluteY;

            const w = n.type === 'customDevice' ? 210 : 180;
            const h = n.type === 'customDevice' ? 140 : 80;
            if (absoluteX + w > maxX) maxX = absoluteX + w;
            if (absoluteY + h > maxY) maxY = absoluteY + h;
        });

        const groupId = `group-${Date.now()}`;
        const groupWidth = (maxX - minX) + padding * 2;
        const groupHeight = (maxY - minY) + padding * 2;
        const groupX = minX - padding;
        const groupY = minY - padding;

        const newGroup = {
            id: groupId,
            type: 'customGroup',
            position: { x: groupX, y: groupY },
            style: { width: groupWidth, height: groupHeight },
            data: { label: 'Group' },
        };

        setNodes(nds => {
            const nextNodes = nds.map(n => {
                if (n.selected && n.type !== 'customGroup') {
                    const absoluteX = n.parentNode ? n.position.x + (nds.find(p => p.id === n.parentNode)?.position.x || 0) : n.position.x;
                    const absoluteY = n.parentNode ? n.position.y + (nds.find(p => p.id === n.parentNode)?.position.y || 0) : n.position.y;
                    return {
                        ...n,
                        parentNode: groupId,
                        extent: 'parent',
                        position: { x: absoluteX - groupX, y: absoluteY - groupY },
                        selected: false,
                    };
                }
                return n;
            });
            return [newGroup, ...nextNodes];
        });
        showToast('success', 'Group berhasil dibuat!');
    };

    const handleUngroup = () => {
        const selectedGroups = nodes.filter(n => n.selected && n.type === 'customGroup');
        const selectedNodesInGroup = nodes.filter(n => n.selected && n.parentNode);

        if (selectedGroups.length === 0 && selectedNodesInGroup.length === 0) {
            showToast('warning', 'Pilih grup atau perangkat dalam grup untuk di-ungroup');
            return;
        }

        setNodes(nds => {
            const groupsToRemove = new Set(selectedGroups.map(g => g.id));

            let finalNodes = nds.filter(n => !groupsToRemove.has(n.id)).map(n => {
                if (groupsToRemove.has(n.parentNode) || (n.selected && n.parentNode)) {
                    const groupNode = nds.find(g => g.id === n.parentNode);
                    if (groupNode) {
                        const { parentNode, extent, ...rest } = n;
                        return {
                            ...rest,
                            position: {
                                x: n.position.x + groupNode.position.x,
                                y: n.position.y + groupNode.position.y,
                            },
                        };
                    }
                }
                return n;
            });

            const validParentIds = new Set(finalNodes.filter(n => n.type === 'customGroup').map(n => n.id));
            finalNodes = finalNodes.map(n => {
                if (n.parentNode && !validParentIds.has(n.parentNode)) {
                    const { parentNode, extent, ...rest } = n;
                    return rest;
                }
                return n;
            });

            return finalNodes;
        });
        showToast('success', 'Ungroup berhasil!');
    };

    const onNodesChange = (changes) => setNodes((nds) => applyNodeChanges(changes, nds));
    const onEdgesChange = (changes) => setEdges((eds) => applyEdgeChanges(changes, eds));

    return {
        nodes,
        setNodes,
        edges,
        setEdges,
        defaultEdges,
        handleGroup,
        handleUngroup,
        onNodesChange,
        onEdgesChange
    };
};
