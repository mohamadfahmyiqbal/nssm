import React from 'react';
import { Handle, Position } from 'reactflow';
import { Network, MapPin, Activity } from 'lucide-react';

export default function CustomDeviceNode({ data, selected }) {
    const isWarning = data.status === 'warning';
    const isDown = data.status === 'down';

    let borderColor = 'border-emerald-500/30 group-hover:border-emerald-400/60';
    let bgGradient = 'from-slate-900/90 to-slate-950/90';
    let badgeColor = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    let iconBg = 'bg-emerald-500/10 border-emerald-500/20';
    let iconColor = 'text-emerald-400';
    let glowShadow = 'shadow-[0_0_20px_rgba(16,185,129,0.1)]';

    if (isDown) {
        borderColor = 'border-rose-500/50 group-hover:border-rose-400/80';
        bgGradient = 'from-rose-950/80 to-slate-950/90';
        badgeColor = 'bg-rose-500/10 text-rose-400 border-rose-500/30 font-bold';
        iconBg = 'bg-rose-500/20 border-rose-500/30';
        iconColor = 'text-rose-400';
        glowShadow = 'shadow-[0_0_20px_rgba(244,63,94,0.2)]';
    } else if (isWarning) {
        borderColor = 'border-amber-500/50 group-hover:border-amber-400/80';
        bgGradient = 'from-amber-950/80 to-slate-950/90';
        badgeColor = 'bg-amber-500/10 text-amber-400 border-amber-500/20';
        iconBg = 'bg-amber-500/20 border-amber-500/30';
        iconColor = 'text-amber-400';
        glowShadow = 'shadow-[0_0_20px_rgba(245,158,11,0.15)]';
    } else if (data.vlan?.includes('CCTV')) {
        borderColor = 'border-purple-500/40 group-hover:border-purple-400/70';
        bgGradient = 'from-purple-950/60 to-slate-950/90';
        badgeColor = 'bg-purple-500/10 text-purple-400 border-purple-500/20';
        iconBg = 'bg-purple-500/10 border-purple-500/20';
        iconColor = 'text-purple-400';
        glowShadow = 'shadow-[0_0_20px_rgba(168,85,247,0.15)]';
    }

    return (
        <div className={`group relative w-72 bg-gradient-to-br ${bgGradient} rounded-2xl border ${borderColor} p-4 backdrop-blur-xl text-center font-sans transition-all duration-300 ${glowShadow} ${selected ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-[#070c14] shadow-[0_0_30px_rgba(59,130,246,0.3)] z-50' : 'z-10'}`}>
            <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl pointer-events-none"></div>

            {/* Top Handles */}
            <Handle type="target" position={Position.Top} id="t-top" className="!bg-slate-400 !w-2 !h-2 !border-slate-800" style={{ left: '50%' }} />
            <Handle type="source" position={Position.Top} id="s-top" className="!bg-slate-400 !w-2 !h-2 !opacity-0" style={{ left: '50%' }} />

            {/* Left Handles */}
            <Handle type="target" position={Position.Left} id="t-left" className="!bg-slate-400 !w-2 !h-2 !border-slate-800" style={{ top: '48px' }} />
            <Handle type="source" position={Position.Left} id="s-left" className="!bg-slate-400 !w-2 !h-2 !opacity-0" style={{ top: '48px' }} />

            {/* Right Handles */}
            <Handle type="target" position={Position.Right} id="t-right" className="!bg-slate-400 !w-2 !h-2 !border-slate-800" style={{ top: '48px' }} />
            <Handle type="source" position={Position.Right} id="s-right" className="!bg-slate-400 !w-2 !h-2 !opacity-0" style={{ top: '48px' }} />

            {/* Header / Badges */}
            <div className="flex justify-between items-center mb-3">
                <span className={`text-[9px] font-bold px-2.5 py-0.5 rounded-md border ${badgeColor} shadow-inner`}>
                    {data.vlan || 'LAN • VLAN 10'}
                </span>
                {data.floor && (
                    <span className="text-[9px] text-slate-300 font-medium flex items-center gap-1 bg-slate-900/80 px-2 py-0.5 rounded-md border border-slate-700/50">
                        <MapPin className="w-2.5 h-2.5 text-blue-400" /> {data.floor}
                    </span>
                )}
            </div>

            {/* Icon Center */}
            <div className="flex justify-center my-3 relative">
                {isDown && (
                    <div className="absolute inset-0 bg-rose-500/20 blur-xl rounded-full"></div>
                )}
                <div className={`p-3 rounded-xl border ${iconBg} shadow-inner relative z-10 group-hover:scale-110 transition-transform duration-300`}>
                    <Network className={`w-6 h-6 ${iconColor}`} />
                </div>
            </div>

            {/* Title & Desc */}
            <div className="font-bold text-sm text-slate-100 tracking-wide break-words group-hover:text-blue-200 transition-colors">
                {data.label}
            </div>

            {/* Location Box */}
            {data.location && (
                <div className="text-[10px] text-blue-300/90 font-medium bg-blue-950/30 border border-blue-900/40 rounded-lg px-2 py-1 mt-2.5 whitespace-normal shadow-inner">
                    {data.location}
                </div>
            )}

            {/* Port Grid (48 Ports) */}
            <div className="mt-4 px-1">
                <div className="text-[8px] text-slate-500 font-bold text-left mb-1 uppercase tracking-widest">Network Ports</div>
                <div 
                    className="grid gap-[2px] p-1.5 bg-slate-950/80 rounded-lg border border-slate-800/80" 
                    style={{ gridTemplateColumns: 'repeat(24, minmax(0, 1fr))' }}
                >
                    {Array.from({ length: 48 }).map((_, i) => {
                        const portNum = i + 1;
                        let isUp = false;
                        if (data.ports) {
                            // Cek apakah port dengan shortName atau index yang sama statusnya up
                            const pData = data.ports.find(p => String(p.shortName) === String(portNum) || String(p.index) === String(portNum));
                            if (pData && pData.status === 'up') isUp = true;
                        }

                        return (
                            <div key={`port-${portNum}`} className={`relative w-full aspect-square rounded-[2px] border transition-colors group/port ${isUp ? 'bg-emerald-500 border-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.8)] z-10' : 'bg-slate-800/80 border-slate-700/50 hover:bg-slate-600'}`} title={`Port ${portNum} ${isUp ? '(UP)' : ''}`}>
                                {/* Hidden handles overlaid on the port */}
                                <Handle 
                                    type="target" 
                                    position={Position.Bottom} 
                                    id={`p-${portNum}`} 
                                    className="!opacity-0 !w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none" 
                                    style={{ position: 'absolute' }} 
                                />
                                <Handle 
                                    type="source" 
                                    position={Position.Bottom} 
                                    id={`s-p-${portNum}`} 
                                    className="!opacity-0 !w-full !h-full !min-w-0 !min-h-0 !border-0 !m-0 !transform-none !left-0 !top-0 !rounded-none hidden" 
                                    style={{ position: 'absolute' }} 
                                />
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Footer Status */}
            <div className="mt-3 pt-2.5 border-t border-slate-700/50 text-[9px] font-bold text-slate-400 flex items-center justify-between px-1">
                <div className="flex items-center gap-1.5">
                    {(!data.vlan?.includes('CCTV') && !data.vendor?.toLowerCase().includes('camera') && !data.label?.toLowerCase().includes('cam')) && (
                        <>
                            <Activity className="w-3 h-3 text-slate-500" />
                            <span>CPU: {data.cpu || 'N/A'}</span>
                        </>
                    )}
                </div>
                <div className="flex items-center gap-1.5">
                    <span className="tracking-wider">{isDown ? 'OFFLINE' : isWarning ? 'WARNING' : 'ONLINE'}</span>
                    <span className={`relative flex w-2 h-2`}>
                        {isDown && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>}
                        <span className={`relative inline-flex rounded-full w-2 h-2 ${isDown ? 'bg-rose-500' : isWarning ? 'bg-amber-500' : 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]'}`}></span>
                    </span>
                </div>
            </div>

            {/* Bottom Handles */}
            <Handle type="target" position={Position.Bottom} id="t-bottom" className="!bg-slate-400 !w-2 !h-2 !border-slate-800" style={{ left: '50%' }} />
            <Handle type="source" position={Position.Bottom} id="s-bottom" className="!bg-slate-400 !w-2 !h-2 !opacity-0" style={{ left: '50%' }} />
            <Handle type="target" position={Position.Bottom} id="t-bot" className="!bg-slate-400 !w-2 !h-2 !border-slate-800 hidden" style={{ left: '50%' }} />
            <Handle type="source" position={Position.Bottom} id="s-bot" className="!bg-slate-400 !w-2 !h-2 !opacity-0 hidden" style={{ left: '50%' }} />
        </div>
    );
}